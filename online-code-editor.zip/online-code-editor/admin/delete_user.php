<?php
session_start();
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    echo json_encode(['status'=>'error', 'message'=>'Not authorized']);
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get user id from POST data
    $id = $_POST['id'];
    
    // Database connection parameters
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "online_editor";
    
    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        echo json_encode(['status'=>'error', 'message'=>'Database connection failed']);
        exit;
    }
    
    // Prepare delete statement
    $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
    $stmt->bind_param("i", $id);
    
    if ($stmt->execute()) {
        echo json_encode(['status' => 'success']);
    } else {
        echo json_encode(['status'=>'error', 'message'=>'Deletion failed']);
    }
    
    $stmt->close();
    $conn->close();
}
?>
