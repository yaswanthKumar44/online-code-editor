<?php
session_start();
// If already logged in, redirect to home.php
if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) {
    header("Location: home.php");
    exit;
}

$error = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];
    $password = $_POST["password"];
    // Check credentials
    if ($email === "yash@gmail.com" && $password === "12345") {
        $_SESSION['logged_in'] = true;
        header("Location: home.php");
        exit;
    } else {
        $error = "Invalid Email or Password";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin Login</title>
  <style>
    /* Full Screen Background with Gradient and Wavy Overlay */
    body {
      background: linear-gradient(to bottom, #ADD8E6, #E6E6FA, #9370DB, #000080);
      margin: 0;
      font-family: sans-serif;
      color: #333;
      position: relative;
      min-height: 100vh;
      overflow: hidden;
      display: flex;
      justify-content: center;
      align-items: center;
    }
    body::before {
      content: "";
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: linear-gradient(to bottom, rgba(255, 255, 255, 0.3), transparent);
      clip-path: polygon(0 20%, 100% 0, 100% 80%, 0 100%);
      pointer-events: none;
      z-index: 0;
    }
    /* Content placed above the overlay */
    .content {
      position: relative;
      z-index: 1;
      text-align: center;
      padding: 20px;
      width: 100%;
      max-width: 400px;
      margin: auto;
    }
    h1 {
      color: #fff;
      text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
      margin-bottom: 20px;
    }
    p {
      line-height: 1.6;
    }
    .login-container {
      border: 2px solid #fff;
      padding: 20px;
      background: rgba(255, 255, 255, 0.8);
      border-radius: 5px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    }
    input[type="text"],
    input[type="password"] {
      width: 80%;
      padding: 10px;
      margin: 10px 0;
      background-color: #fff;
      border: 1px solid #ccc;
      color: #333;
      border-radius: 4px;
      transition: box-shadow 0.3s ease;
    }
    input[type="text"]:focus,
    input[type="password"]:focus {
      box-shadow: 0 0 5px rgba(0, 0, 0, 0.3);
    }
    input[type="submit"] {
      width: 85%;
      padding: 10px;
      margin: 10px 0;
      background-color: #333;
      color: #fff;
      border: none;
      cursor: pointer;
      border-radius: 4px;
      transition: transform 0.2s ease, background-color 0.3s ease;
    }
    input[type="submit"]:hover {
      transform: scale(1.05);
      background-color: #555;
    }
    .error {
      color: red;
    }
    /* Show Password Toggle Styling */
    .show-password {
      margin: 10px 0;
      font-size: 0.9em;
      color: #333;
      cursor: pointer;
      user-select: none;
    }
    .emoji {
      margin-right: 5px;
      font-size: 1.2em;
    }
  </style>
</head>
<body>
  <div class="content">
      <h1><span class="emoji">🔒</span>Login</h1>
      <div class="login-container">
        <?php if ($error != "") { echo '<p class="error">'.$error.'</p>'; } ?>
        <form method="post">
          <input type="text" name="email" placeholder="📧 Email" required><br>
          <input type="password" name="password" placeholder="🔑 Password" id="password" required><br>
          <div class="show-password">
            <input type="checkbox" id="togglePassword">
            <label for="togglePassword"><span class="emoji">👁️</span>Show Password</label>
          </div>
          <input type="submit" value="🔑 Login">
        </form>
      </div>
  </div>
  <script>
    // Toggle the visibility of the password field
    const togglePassword = document.getElementById('togglePassword');
    const passwordInput = document.getElementById('password');
    togglePassword.addEventListener('change', function () {
      const type = this.checked ? 'text' : 'password';
      passwordInput.setAttribute('type', type);
    });
  </script>
</body>
</html>
