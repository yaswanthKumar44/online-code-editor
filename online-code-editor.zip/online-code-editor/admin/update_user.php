<?php
session_start();
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    echo json_encode(['status'=>'error', 'message'=>'Not authorized']);
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $gender = $_POST['gender'];
    $dob = $_POST['dob'];
    $phone = $_POST['phone_number'];
    $role = $_POST['role'];
    
    // Database connection parameters
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "online_editor";
    
    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        echo json_encode(['status'=>'error', 'message'=>'Database connection failed']);
        exit;
    }
    
    // Prepare update statement
    $stmt = $conn->prepare("UPDATE users SET name = ?, email = ?, gender = ?, dob = ?, phone_number = ?, role = ? WHERE id = ?");
    $stmt->bind_param("ssssssi", $name, $email, $gender, $dob, $phone, $role, $id);
    
    if ($stmt->execute()) {
        echo json_encode([
          'status' => 'success', 
          'data' => [
              'id' => $id, 
              'name' => $name, 
              'email' => $email, 
              'gender' => $gender, 
              'dob' => $dob, 
              'phone_number' => $phone, 
              'role' => $role
          ]
        ]);
    } else {
        echo json_encode(['status'=>'error', 'message'=>'Update failed']);
    }
    $stmt->close();
    $conn->close();
}
?>
