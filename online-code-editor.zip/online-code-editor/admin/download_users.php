<?php
session_start();
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header("Location: login.php");
    exit;
}
require('../fpdf/fpdf.php'); // Ensure FPDF is installed in the "fpdf" folder

// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "online_editor";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT id, name, email, registration_date, gender, dob, phone_number, role FROM users";
$result = $conn->query($sql);

$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial','B',16);
$pdf->Cell(0,10,'Users List',0,1,'C');
$pdf->Ln(5);

$pdf->SetFont('Arial','B',12);
$pdf->Cell(10,10,'ID',1);
$pdf->Cell(40,10,'Name',1);
$pdf->Cell(60,10,'Email',1);
$pdf->Cell(30,10,'Gender',1);
$pdf->Cell(30,10,'DOB',1);
$pdf->Cell(30,10,'Role',1);
$pdf->Ln();

$pdf->SetFont('Arial','',12);
if($result && $result->num_rows > 0){
    while($row = $result->fetch_assoc()){
        $pdf->Cell(10,10,$row['id'],1);
        $pdf->Cell(40,10,$row['name'],1);
        $pdf->Cell(60,10,$row['email'],1);
        $pdf->Cell(30,10,$row['gender'],1);
        $pdf->Cell(30,10,$row['dob'],1);
        $pdf->Cell(30,10,$row['role'],1);
        $pdf->Ln();
    }
}

$conn->close();
$pdf->Output('D', 'users_list.pdf');
?>
