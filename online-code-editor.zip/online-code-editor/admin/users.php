<?php
session_start();
// Redirect to login.php if not logged in
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header("Location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Users List</title>
  <style>
    /* Full-Screen Gradient Background with Wavy Overlay */
    body {
      background: linear-gradient(to bottom, #ADD8E6, #E6E6FA, #9370DB, #000080);
      margin: 0;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      color: #333;
      position: relative;
      min-height: 100vh;
      overflow: auto;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: flex-start;
      padding-top: 30px;
    }
    body::before {
      content: "";
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: linear-gradient(to bottom, rgba(255,255,255,0.3), transparent);
      clip-path: polygon(0 20%, 100% 0, 100% 80%, 0 100%);
      pointer-events: none;
      z-index: 0;
    }
    /* Content Container Above Overlay */
    .content {
      position: relative;
      z-index: 1;
      width: 95%;
      max-width: 1200px;
      padding: 20px;
    }
    h1 {
      color: #fff;
      text-shadow: 2px 2px 4px rgba(0,0,0,0.5);
      margin-bottom: 20px;
      text-align: center;
    }
    /* Navigation Button Styling */
    .nav-buttons {
      text-align: center;
      margin-bottom: 20px;
    }
    a.button {
      display: inline-block;
      padding: 10px 20px;
      margin: 10px;
      text-decoration: none;
      color: #fff;
      font-weight: bold;
      border-radius: 8px;
      background: linear-gradient(45deg, #ff6ec4, #7873f5);
      box-shadow: 0 4px 6px rgba(0,0,0,0.1);
      transition: transform 0.2s, box-shadow 0.2s;
    }
    a.button:hover {
      transform: scale(1.05);
      box-shadow: 0 6px 8px rgba(0,0,0,0.2);
    }
    /* Table Styling */
    table {
      width: 100%;
      margin: 20px auto;
      border-collapse: collapse;
      background-color: rgba(255, 255, 255, 0.9);
      border-radius: 5px;
      overflow: hidden;
    }
    th, td {
      border: 1px solid #fff;
      padding: 10px;
      color: #333;
      text-align: center;
    }
    th {
      background-color: #fff;
      color: #000;
    }
    /* Modal Styling (Do Not Remove Any Pop-Up Message Styles) */
    .modal {
      display: none; 
      position: fixed; 
      z-index: 1000; 
      left: 0;
      top: 0;
      width: 100%;
      height: 100%;
      overflow: auto;
      background-color: rgba(0,0,0,0.8);
    }
    .modal-content {
      background-color: #000;
      margin: 10% auto;
      padding: 20px;
      border: 2px solid #ff6ec4;
      width: 50%;
      color: #ff6ec4;
      border-radius: 8px;
      box-shadow: 0 6px 10px rgba(0,0,0,0.3);
      position: relative;
    }
    .close {
      color: #ff6ec4;
      position: absolute;
      top: 10px;
      right: 15px;
      font-size: 28px;
      font-weight: bold;
      cursor: pointer;
    }
    /* Profile Photo Styling */
    .profile-photo {
      width: 50px;
      height: 50px;
      object-fit: cover;
      border-radius: 50%;
      border: 2px solid #ff6ec4;
    }
    /* SweetAlert2 Customization */
    .swal2-popup {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      border-radius: 10px;
      background: linear-gradient(45deg, #ff6ec4, #7873f5);
      color: #fff;
    }
    .swal2-title {
      font-size: 1.5em;
      font-weight: bold;
    }
    .swal2-content {
      font-size: 1.1em;
    }
    /* Emoji Styling */
    .emoji {
      font-size: 1.2em;
      margin-right: 5px;
    }
  </style>
  <!-- Include SweetAlert2 for Professional Pop-Ups -->
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <!-- Include jQuery for AJAX and DOM Manipulation -->
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
  <div class="content">
    <h1>Users List</h1>
    <div class="nav-buttons">
      <a class="button" href="home.php"><span class="emoji">🏠</span>Back to Home</a>
      <a id="downloadPdf" class="button" href="download_users.php"><span class="emoji">📄</span>Download PDF</a>
      <a class="button" href="logout.php"><span class="emoji">🚪</span>Logout</a>
    </div>
    <?php
    // Database connection parameters
    $servername = "localhost";
    $username = "root";      // change as needed
    $password = "";          // change as needed
    $dbname = "online_editor";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("<p>Connection failed: " . $conn->connect_error . "</p>");
    }

    // Query to fetch all users
    $sql = "SELECT id, name, email, registration_date, profile_photo, gender, dob, phone_number, role FROM users";
    $result = $conn->query($sql);

    if ($result && $result->num_rows > 0) {
        echo "<table>";
        echo "<tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Registration Date</th>
                <th>Gender</th>
                <th>DOB</th>
                <th>Phone Number</th>
                <th>Role</th>
                <th>Actions</th>
              </tr>";
        while($row = $result->fetch_assoc()) {
            echo "<tr id='userRow_".$row['id']."'>";
            echo "<td>" . $row["id"] . "</td>";
            echo "<td class='name'>" . htmlspecialchars($row["name"]) . "</td>";
            echo "<td class='email'>" . htmlspecialchars($row["email"]) . "</td>";
            echo "<td>" . $row["registration_date"] . "</td>";
            echo "<td class='gender'>" . $row["gender"] . "</td>";
            echo "<td class='dob'>" . $row["dob"] . "</td>";
            echo "<td class='phone_number'>" . $row["phone_number"] . "</td>";
            echo "<td class='role'>" . $row["role"] . "</td>";
            echo "<td>
                    <a class='button editBtn' 
                       data-id='".$row['id']."' 
                       data-name='".htmlspecialchars($row['name'], ENT_QUOTES)."' 
                       data-email='".htmlspecialchars($row['email'], ENT_QUOTES)."' 
                       data-gender='".$row['gender']."' 
                       data-dob='".$row['dob']."' 
                       data-phone='".$row['phone_number']."' 
                       data-role='".$row['role']."'><span class='emoji'>✏️</span>Edit</a>
                    <a class='button deleteBtn' 
                       data-id='".$row['id']."' 
                       data-name='".htmlspecialchars($row['name'], ENT_QUOTES)."'><span class='emoji'>🗑️</span>Delete</a>
                  </td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p>No users found.</p>";
    }

    $conn->close();
    ?>

    <!-- Modal for Editing User Details -->
    <div id="editModal" class="modal">
      <div class="modal-content">
        <span class="close">&times;</span>
        <h2>Edit User Details</h2>
        <form id="editForm">
          <input type="hidden" name="id" id="userId">
          <label>Name:</label><br>
          <input type="text" name="name" id="userName" required><br><br>
          <label>Email:</label><br>
          <input type="email" name="email" id="userEmail" required readonly><br><br>
          <label>Gender:</label><br>
          <select name="gender" id="userGender">
            <option value="Male">Male</option>
            <option value="Female">Female</option>
            <option value="Other">Other</option>
          </select><br><br>
          <label>Date of Birth:</label><br>
          <input type="date" name="dob" id="userDob"><br><br>
          <label>Phone Number:</label><br>
          <input type="text" name="phone_number" id="userPhone"><br><br>
          <label>Role:</label><br>
          <select name="role" id="userRole">
            <option value="Student">Student</option>
            <option value="Faculty">Faculty</option>
            <option value="Other">Other</option>
          </select><br><br>
          <button type="submit" class="button"><span class="emoji">💾</span>Save Changes</button>
        </form>
      </div>
    </div>
  </div>

  <script>
    // Get modal element
    var modal = document.getElementById("editModal");
    // Get <span> element that closes the modal
    var span = document.getElementsByClassName("close")[0];

    // When the user clicks on <span> (x), close the modal
    span.onclick = function() {
      modal.style.display = "none";
    }
    // When the user clicks anywhere outside the modal, close it
    window.onclick = function(event) {
      if (event.target == modal) {
        modal.style.display = "none";
      }
    }

    // Edit button click handler
    $('.editBtn').on('click', function() {
      var id = $(this).data('id');
      var name = $(this).data('name');
      var email = $(this).data('email');
      var gender = $(this).data('gender');
      var dob = $(this).data('dob');
      var phone = $(this).data('phone');
      var role = $(this).data('role');
      
      // Fill the form with user data
      $('#userId').val(id);
      $('#userName').val(name);
      $('#userEmail').val(email);
      $('#userGender').val(gender);
      $('#userDob').val(dob);
      $('#userPhone').val(phone);
      $('#userRole').val(role);
      
      modal.style.display = "block";
    });

    // Delete button click handler
    $('.deleteBtn').on('click', function() {
      var id = $(this).data('id');
      var name = $(this).data('name');
      Swal.fire({
        title: 'Are you sure?',
        text: "Do you really want to delete user '" + name + "'?",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, delete it!',
        cancelButtonText: 'Cancel'
      }).then((result) => {
        if (result.isConfirmed) {
          $.ajax({
            url: 'delete_user.php',
            type: 'POST',
            data: { id: id },
            success: function(response) {
              var res = JSON.parse(response);
              if(res.status == 'success'){
                // Remove the row from the table
                $('#userRow_' + id).remove();
                Swal.fire({
                  icon: 'success',
                  title: 'Deleted!',
                  text: 'User has been deleted.',
                  timer: 2000,
                  showConfirmButton: false
                });
              } else {
                Swal.fire({
                  icon: 'error',
                  title: 'Error',
                  text: 'Failed to delete the user. Please try again.'
                });
              }
            },
            error: function() {
              Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'An unexpected error occurred.'
              });
            }
          });
        }
      });
    });

    // Form submit handler using AJAX for editing
    $('#editForm').on('submit', function(e) {
      e.preventDefault();
      $.ajax({
        url: 'update_user.php',
        type: 'POST',
        data: $(this).serialize(),
        success: function(response) {
          var res = JSON.parse(response);
          if(res.status == 'success'){
            // Update the table row with new data
            var row = $('#userRow_' + res.data.id);
            row.find('.name').text(res.data.name);
            row.find('.email').text(res.data.email);
            row.find('.gender').text(res.data.gender);
            row.find('.dob').text(res.data.dob);
            row.find('.phone_number').text(res.data.phone_number);
            row.find('.role').text(res.data.role);
            
            Swal.fire({
              icon: 'success',
              title: 'Success',
              text: 'User details updated successfully!',
              timer: 2000,
              showConfirmButton: false
            });
            
            modal.style.display = "none";
          } else {
            Swal.fire({
              icon: 'error',
              title: 'Error',
              text: 'Failed to update user details. Please try again.'
            });
          }
        },
        error: function() {
          Swal.fire({
            icon: 'error',
            title: 'Error',
            text: 'An unexpected error occurred.'
          });
        }
      });
    });

    // Download button click handler with confirmation pop-up
    $('#downloadPdf').on('click', function(e) {
      e.preventDefault();
      Swal.fire({
        title: 'Download PDF',
        text: "Do you want to download the users list as a PDF?",
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Yes, download it!',
        cancelButtonText: 'Cancel'
      }).then((result) => {
        if (result.isConfirmed) {
          Swal.fire({
            toast: true,
            position: 'top-end',
            icon: 'success',
            title: 'Download initiated',
            showConfirmButton: false,
            timer: 1500
          });
          window.location.href = $(this).attr('href');
        }
      });
    });
  </script>
</body>
</html>
