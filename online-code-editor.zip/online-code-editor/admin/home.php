<?php
session_start();
// Redirect to login.php if not logged in
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header("Location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Home</title>
  <style>
    /* Full Screen Gradient Background with Wavy Overlay */
    body {
      background: linear-gradient(to bottom, #ADD8E6, #E6E6FA, #9370DB, #000080);
      margin: 0;
      font-family: sans-serif;
      color: #333;
      position: relative;
      min-height: 100vh;
      overflow: hidden;
      display: flex;
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    body::before {
      content: "";
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: linear-gradient(to bottom, rgba(255, 255, 255, 0.3), transparent);
      clip-path: polygon(0 20%, 100% 0, 100% 80%, 0 100%);
      pointer-events: none;
      z-index: 0;
    }
    /* Content above the overlay */
    .content {
      position: relative;
      z-index: 1;
      padding: 20px;
    }
    h1 {
      color: #fff;
      text-shadow: 2px 2px 4px rgba(0,0,0,0.5);
      margin-bottom: 20px;
    }
    /* Navigation Button Styling with Emoji */
    .nav a {
      color: #fff;
      text-decoration: none;
      border: 2px solid #fff;
      padding: 10px 20px;
      margin: 10px;
      display: inline-block;
      transition: transform 0.2s ease, background-color 0.3s ease, color 0.3s ease;
    }
    .nav a:hover {
      background-color: #fff;
      color: #000;
      transform: scale(1.05);
    }
    .emoji {
      margin-right: 5px;
      font-size: 1.2em;
    }
  </style>
</head>
<body>
  <div class="content">
    <h1>🏠 Welcome to the Home Page</h1>
    <div class="nav">
      <a href="users.php"><span class="emoji">👥</span>View Users</a>
      <a href="logout.php"><span class="emoji">🚪</span>Logout</a>
    </div>
  </div>
</body>
</html>
