<?php
session_start();
header('Content-Type: text/plain');

// ================================================
// 1. Configure Java Path (QUOTED for Windows spaces)
// ================================================
$javaPath = '"C:\\Program Files\\Java\\jdk-21.0.2\\bin"'; 
putenv("PATH=$javaPath;" . getenv("PATH"));

// ================================================
// 2. Validate Input
// ================================================
$code = $_POST['code'] ?? '';
$input = $_POST['input'] ?? '';

if (empty($code)) {
    die("Error: No Java code submitted.");
}

// Ensure code contains "public class Main"
if (!preg_match('/public\s+class\s+Main\b/', $code)) {
    die("Error: Your code must have 'public class Main'.");
}

// ================================================
// 3. Write Files
// ================================================
file_put_contents("Main.java", $code);
if ($input) {
    file_put_contents("input.txt", $input);
}

// ================================================
// 4. Compile Java Code (Log Errors)
// ================================================
$compileCommand = "javac Main.java 2>&1"; // Capture errors
$compileOutput = shell_exec($compileCommand);

// If compilation failed, show error
if ($compileOutput !== null) {
    file_put_contents("compile_error.txt", $compileOutput);
    $error = file_get_contents("compile_error.txt");
    if (!empty(trim($error))) {
        die("COMPILE ERROR:\n" . trim($error));
    }
}

// ================================================
// 5. Run Java Program (Handle Input)
// ================================================
// Use -cp . to include the current directory in the classpath
$runCommand = "java -cp . Main";
if (!empty($input)) {
    // Windows: Use 'type' to pipe input from file
    $runCommand = "type input.txt | java -cp . Main";
}

// Capture runtime output/errors
$output = shell_exec("$runCommand 2>&1");

// ================================================
// 6. Display Output
// ================================================
if ($output === null) {
    echo "No output or runtime error.";
} else {
    echo trim($output);
}

// ================================================
// 7. Cleanup Files
// ================================================
$filesToDelete = ["Main.java", "Main.class", "input.txt", "compile_error.txt"];
foreach ($filesToDelete as $file) {
    if (file_exists($file)) {
        @unlink($file);
    }
}
?>
