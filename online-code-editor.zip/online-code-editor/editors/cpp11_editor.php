<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>C++11 Editor - Online Code Editor</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    :root {
      --bg-color: #f8f9fa;
      --text-color: #212529;
      --editor-bg: #ffffff;
      --border-color: #dee2e6;
      --button-bg: linear-gradient(135deg, #280054 0%, #3A0079 30%, #0000FF 60%, #FF0000 100%);
      --header-bg: linear-gradient(135deg, #280054 0%, #3A0079 30%, #0000FF 60%, #FF0000 100%);
    }
    .dark-mode {
      --bg-color: #121212;
      --text-color: #e0e0e0;
      --editor-bg: #1e1e1e;
      --border-color: #333333;
      --button-bg: linear-gradient(135deg, #1a0033 0%, #2a0057 30%, #0000cc 60%, #cc0000 100%);
      --header-bg: linear-gradient(135deg, #1a0033 0%, #2a0057 30%, #0000cc 60%, #cc0000 100%);
    }
    body {
      font-family: 'Segoe UI', system-ui, sans-serif;
      background: var(--bg-color);
      color: var(--text-color);
      margin: 0;
      transition: all 0.3s ease;
    }
    header {
      background: var(--header-bg);
      color: white;
      padding: 1rem;
      display: flex;
      justify-content: space-between;
      align-items: center;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }
    .container {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 20px;
      height: calc(100vh - 150px);
      padding: 20px;
      max-width: 1600px;
      margin: 0 auto;
    }
    .editor-panel, .output-panel {
      background: var(--editor-bg);
      border: 1px solid var(--border-color);
      border-radius: 12px;
      padding: 1rem;
      display: flex;
      flex-direction: column;
      position: relative;
      box-shadow: 0 4px 12px rgba(0,0,0,0.05);
    }
    /* Notes name input (optional) */
    #notesName {
      width: 100%;
      padding: 0.5rem;
      margin-bottom: 1rem;
      border: 1px solid var(--border-color);
      border-radius: 8px;
      font-size: 14px;
    }
    textarea, #output {
      flex: 1;
      padding: 1rem;
      border: 1px solid var(--border-color);
      border-radius: 8px;
      font-family: 'Fira Code', monospace;
      font-size: 14px;
      background: var(--editor-bg);
      color: var(--text-color);
      resize: none;
      margin-bottom: 1rem;
      transition: background 0.3s, color 0.3s;
    }
    #output {
      white-space: pre-wrap;
      overflow-y: auto;
    }
    .brush-button {
      position: absolute;
      top: 10px;
      right: 10px;
      background: var(--button-bg);
      border: none;
      color: white;
      border-radius: 50%;
      width: 30px;
      height: 30px;
      cursor: pointer;
      font-weight: bold;
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 2px 8px rgba(0,0,0,0.2);
      transition: transform 0.3s;
    }
    .brush-button:hover {
      transform: scale(1.1);
    }
    #runButton, #saveNotesButton, #stopButton {
      background: var(--button-bg);
      color: white;
      border: none;
      padding: 12px 24px;
      border-radius: 8px;
      cursor: pointer;
      font-weight: 600;
      transition: transform 0.3s, box-shadow 0.3s;
      margin-top: 10px;
      margin-right: 10px;
    }
    #runButton:hover, #saveNotesButton:hover, #stopButton:hover {
      transform: scale(1.05);
      box-shadow: 0 4px 12px rgba(0,0,0,0.2);
    }
    @keyframes cleanEffect {
      0% { opacity: 1; }
      50% { opacity: 0.2; }
      100% { opacity: 1; }
    }
    .cleaning {
      animation: cleanEffect 0.5s ease;
    }
    .spinner {
      display: inline-block;
      width: 16px;
      height: 16px;
      border: 3px solid rgba(0, 0, 0, 0.2);
      border-top-color: #000;
      border-radius: 50%;
      animation: spin 0.8s linear infinite;
      vertical-align: middle;
      margin-right: 8px;
    }
    @keyframes spin {
      to { transform: rotate(360deg); }
    }
    /* Hidden input for language (set by the compiler) */
    #language {
      display: none;
    }
  </style>
</head>
<body>
  <header>
    <h1>C++11 Editor</h1>
    <button id="themeToggle">🌙</button>
  </header>
  <div class="container">
    <div class="editor-panel">
      <!-- Brush button to clear the code area --> 
      <button class="brush-button" onclick="clearField('codeArea')">🖌️</button>
      <!-- Optional: Notes name input --> 
      <input type="text" id="notesName" placeholder="Enter notes name (optional)..." />
      <!-- Code textarea with sample code pre-inserted --> 
      <textarea id="codeArea" placeholder="Write your C++11 code here...">
#include <iostream>
using namespace std;
 
int main() {
    cout << \"Hello, world!\" << endl;
    return 0;
}
      </textarea>
      <!-- Brush button to clear the input area --> 
      <button class="brush-button" style="top: 50%;" onclick="clearField('inputArea')">🖌️</button>
      <!-- Input textarea --> 
      <textarea id="inputArea" placeholder="Enter runtime input (if any)..."></textarea>
      <div style="display: flex; justify-content: flex-end;">
        <button id="stopButton">Stop</button>
        <button id="saveNotesButton">Save Notes</button>
        <button id="runButton">Run Code ▶</button>
      </div>
      <!-- Hidden input for language (default set to C++11) --> 
      <input type="hidden" id="language" value="C++11">
    </div>
    <div class="output-panel">
      <!-- Brush button to clear the output area --> 
      <button class="brush-button" onclick="clearField('output')">🖌️</button>
      <pre id="output"></pre>
    </div>
  </div>
  <script>
    // Set loggedIn flag from PHP; for testing, you may set it to false if undefined.
    const loggedIn = <?php echo json_encode($loggedIn ?? false); ?>;
    
    // Theme toggle functionality
    const themeToggle = document.getElementById('themeToggle');
    const body = document.body;
    themeToggle.addEventListener('click', () => {
      body.classList.toggle('dark-mode');
      const isDark = body.classList.contains('dark-mode');
      themeToggle.textContent = isDark ? '☀️' : '🌙';
      localStorage.setItem('theme', isDark ? 'dark' : 'light');
    });
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'dark') {
      body.classList.add('dark-mode');
      themeToggle.textContent = '☀️';
    }
    
    // Function to clear a field with a cleaning animation
    function clearField(id) {
      const element = document.getElementById(id);
      element.classList.add('cleaning');
      setTimeout(() => {
        element.value = '';
        element.textContent = '';
        element.classList.remove('cleaning');
      }, 300);
    }
    
    // Global variable for aborting compile requests
    let currentCompilationController = null;
    
    // Run Code: compiles and runs the code (no login required)
    document.getElementById('runButton').addEventListener('click', async () => {
      const outputElement = document.getElementById('output');
      if (currentCompilationController) {
        currentCompilationController.abort();
      }
      currentCompilationController = new AbortController();
      outputElement.innerHTML = '<span class="spinner"></span> Compiling...';
      
      try {
        const response = await fetch('../editors/cpp11_compiler.php', {
          method: 'POST',
          headers: {'Content-Type': 'application/x-www-form-urlencoded'},
          body: `code=${encodeURIComponent(document.getElementById('codeArea').value)}&input=${encodeURIComponent(document.getElementById('inputArea').value)}`,
          signal: currentCompilationController.signal
        });
        const result = await response.text();
        outputElement.textContent = result.trim();
      } catch (error) {
        if (error.name === 'AbortError') {
          outputElement.textContent = 'Compilation stopped.';
        } else {
          outputElement.textContent = `Error: ${error.message}`;
        }
      } finally {
        currentCompilationController = null;
      }
    });
    
    // Save Notes: requires login; uses popups to ask for and confirm note name.
    document.getElementById('saveNotesButton').addEventListener('click', async () => {
      if (!loggedIn) {
        alert("You must be logged in to save notes.");
        window.location.href = "../email/login.php";
        return;
      }
      const code = document.getElementById('codeArea').value.trim();
      if (code === "") {
        alert("No code provided to save.");
        return;
      }
      // Ensure that code has been run (output exists)
      const outputText = document.getElementById('output').textContent.trim();
      if (outputText === "") {
        alert("Please run the code before saving notes.");
        return;
      }
      // Get note name from field or prompt if empty.
      let notesName = document.getElementById('notesName') ? document.getElementById('notesName').value.trim() : "";
      if (notesName === "") {
        notesName = prompt("Enter a name for your note:");
        if (!notesName) {
          alert("Note name is required to save.");
          return;
        }
      }
      // Confirm save with a popup
      if (!confirm(`Are you sure you want to save note "${notesName}"?`)) {
         return;
      }
      // Get language from hidden input (or default "C")
      const language = document.getElementById('language').value || "C";
      // Prepare data to send to save_notes.php
      const data = `code=${encodeURIComponent(code)}&output=${encodeURIComponent(outputText)}&notesName=${encodeURIComponent(notesName)}&language=${encodeURIComponent(language)}`;
      try {
        const response = await fetch('../editors/save_notes.php', {
          method: 'POST',
          headers: {'Content-Type': 'application/x-www-form-urlencoded'},
          body: data
        });
        const result = await response.text();
        alert(result.trim());
      } catch (error) {
        alert("Error saving note: " + error.message);
      }
    });
    
    // Stop Compilation: aborts any ongoing compile request
    document.getElementById('stopButton').addEventListener('click', () => {
      if (currentCompilationController) {
        currentCompilationController.abort();
      }
    });
  </script>
</body>
</html>
