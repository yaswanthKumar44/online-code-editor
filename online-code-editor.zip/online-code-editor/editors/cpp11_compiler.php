<?php
session_start();
// Set the MinGW path (ensure this path is correct)
putenv("PATH=C:\\MinGW\\bin;" . getenv("PATH"));

$CC = "g++";  
$filename_code = "main.cpp";
$filename_in = "input.txt";
$filename_error = "error.txt";
$executable = "a.exe";

$code = $_POST["code"] ?? "";
$input = $_POST["input"] ?? "";

if (empty(trim($code))) {
    echo "No code provided.";
    exit;
}

file_put_contents($filename_code, $code);

if (!empty(trim($input))) {
    file_put_contents($filename_in, $input);
}

$command = "$CC -std=c++11 -o $executable $filename_code 2> $filename_error";
shell_exec($command);

$error = file_get_contents($filename_error);
if (trim($error) == "") {
    if (empty(trim($input))) {
        $output = shell_exec("$executable");
    } else {
        $output = shell_exec("$executable < $filename_in");
    }
    echo trim($output);
} else {
    echo trim($error);
}

unlink($filename_code);
if (!empty(trim($input))) unlink($filename_in);
unlink($filename_error);
unlink($executable);
?>
