<?php
// No login check here – running code is open to all.
putenv("PATH=C:\\MinGW\\bin;" . getenv("PATH"));

$CC = "gcc";  
$executable = "a.exe";
$filename_code = "main.c";
$filename_input = "input.txt";
$filename_error = "error.txt";

$code = $_POST["code"] ?? "";
$input = $_POST["input"] ?? "";

if (empty(trim($code))) {
    echo "Error: No code provided.";
    exit();
}

file_put_contents($filename_code, trim($code));
file_put_contents($filename_input, trim($input));

$compile_cmd = "$CC $filename_code -o $executable 2> $filename_error";
shell_exec($compile_cmd);

$error = trim(file_get_contents($filename_error));
if (!empty($error)) {
    echo trim($error);
    cleanup();
    exit();
}

$run_cmd = empty($input) ? "$executable 2>&1" : "$executable < $filename_input 2>&1";
$output = trim(shell_exec($run_cmd));

echo $output;

cleanup();

function cleanup() {
    global $filename_code, $filename_input, $filename_error, $executable;
    @unlink($filename_code);
    @unlink($filename_input);
    @unlink($filename_error);
    @unlink($executable);
}
?>
