<?php
session_start();
if (!isset($_SESSION['email'])) {
    echo "Error: You must be logged in to save notes.";
    exit();
}

// Database configuration
$servername = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "online_editor";
$conn = new mysqli($servername, $dbUsername, $dbPassword, $dbName);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set the MinGW path
putenv("PATH=C:\\MinGW\\bin;" . getenv("PATH"));

$CC = "g++";  
$filename_code = "main.cpp";
$filename_in = "input.txt";
$filename_error = "error.txt";
$executable = "a.exe";

$code = $_POST["code"] ?? "";
$output = $_POST["output"] ?? "";
$notesName = $_POST["notesName"] ?? "";
$language = $_POST["language"] ?? "C++11";

if (empty(trim($code)) || empty(trim($notesName))) {
    echo "Error: Code and note name are required.";
    exit;
}

// If output is empty, compile and run the code to obtain output.
if (empty(trim($output))) {
    file_put_contents($filename_code, $code);
    if (!empty(trim($_POST["input"]))) {
        file_put_contents($filename_in, $_POST["input"]);
    }
    $command = "$CC -std=c++11 -o $executable $filename_code 2> $filename_error";
    shell_exec($command);
    $error = file_get_contents($filename_error);
    if (trim($error) == "") {
        $output = empty(trim($_POST["input"])) ? shell_exec("$executable") : shell_exec("$executable < $filename_in");
        $output = trim($output);
    } else {
        $output = trim($error);
    }
    unlink($filename_code);
    if (!empty(trim($_POST["input"]))) unlink($filename_in);
    unlink($filename_error);
    unlink($executable);
}

$userEmail = $_SESSION['email'];
$date = date("Y-m-d H:i:s");

$submission = array(
    "code" => $code,
    "language" => $language,
    "output" => $output,
    "date" => $date
);

// Check if record for this Gmail and notesName exists
$sql = "SELECT id, submissions FROM saved_notes WHERE gmail = ? AND notesname = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $userEmail, $notesName);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $submissions = json_decode($row['submissions'], true);
    if (!is_array($submissions)) {
        $submissions = array();
    }
    $submissions[] = $submission;
    $submissions_json = json_encode($submissions);
    $updateSql = "UPDATE saved_notes SET submissions = ? WHERE id = ?";
    $updateStmt = $conn->prepare($updateSql);
    $updateStmt->bind_param("si", $submissions_json, $row['id']);
    if ($updateStmt->execute()){
        echo "Note updated successfully.";
    } else {
        echo "Error updating note.";
    }
    $updateStmt->close();
} else {
    $submissions = array($submission);
    $submissions_json = json_encode($submissions);
    $insertSql = "INSERT INTO saved_notes (gmail, notesname, submissions) VALUES (?, ?, ?)";
    $insertStmt = $conn->prepare($insertSql);
    $insertStmt->bind_param("sss", $userEmail, $notesName, $submissions_json);
    if ($insertStmt->execute()){
        echo "Note saved successfully.";
    } else {
        echo "Error saving note.";
    }
    $insertStmt->close();
}
$conn->close();
?>
