<?php
session_start();

// Set Mono path (adjust for your system)
putenv("PATH=C:\\Program Files\\Mono\\bin;" . getenv("PATH"));

$CSharpCompiler = "mcs";
$mono = "mono";
$out = "output.exe";
$filename_code = "main.cs";
$filename_in = "input.txt";
$filename_error = "error.txt";

$code = $_POST["code"] ?? '';
$input = $_POST["input"] ?? '';

if (empty($code)) {
    die("Error: No code provided!");
}

// Write code to file
file_put_contents($filename_code, $code);

// Write input if provided
if (!empty($input)) {
    file_put_contents($filename_in, $input);
}

// Compile the code and redirect errors to the error file
shell_exec("$CSharpCompiler $filename_code -out:$out 2> $filename_error");

// Check for compilation errors
$error = file_get_contents($filename_error);
if (!empty($error)) {
    echo "Compilation Error: <br>" . nl2br(trim($error));
} else {
    // Run the compiled executable using Mono
    $run_command = "$mono " . escapeshellarg(realpath($out)) . " 2>&1";
    if (!empty($input)) {
        $run_command .= " < " . escapeshellarg($filename_in);
    }
    $output = shell_exec($run_command);
    echo nl2br(trim($output));
}

// Cleanup temporary files
@unlink($filename_code);
@unlink($filename_in);
@unlink($filename_error);
@unlink($out);
?>
