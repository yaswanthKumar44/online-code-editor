<?php
// Set the MinGW path (Ensure this path is correct for your MinGW installation)
putenv("PATH=C:\\MinGW\\bin;" . getenv("PATH"));

// Define filenames
$CC = "g++";  // C++ Compiler (MinGW)
$out = "a.exe";  // Output executable file
$code = $_POST["code"] ?? "";
$input = $_POST["input"] ?? "";
$filename_code = "main.cpp";
$filename_in = "input.txt";
$filename_error = "error.txt";
$executable = "a.exe";

// Ensure code is not empty
if (empty(trim($code))) {
    echo "No code provided.";
    exit;
}

// Write code to the file
file_put_contents($filename_code, $code);

// Write input to a file (if provided)
if (!empty(trim($input))) {
    file_put_contents($filename_in, $input);
}

// Compile the C++ code
$command = "$CC -o $executable $filename_code 2> $filename_error";
shell_exec($command);

// Check for compilation errors
$error = file_get_contents($filename_error);

if (trim($error) == "") {
    // Run executable with input if available
    $output = empty(trim($input)) ? shell_exec("$executable") : shell_exec("$executable < $filename_in");

    // Display only the output without any wrapping HTML tags
    echo trim($output);
} else {
    // Display compilation errors without any wrapping HTML tags
    echo trim($error);
}

// Cleanup files
unlink($filename_code);
if (!empty(trim($input))) unlink($filename_in);
unlink($filename_error);
unlink($executable);
?>