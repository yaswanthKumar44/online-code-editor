<?php
session_start();
$loggedIn = isset($_SESSION['email']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Java Editor - Online Code Editor</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- Include SweetAlert2 CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
  <style>
    :root {
      --bg-color: #f8f9fa;
      --text-color: #212529;
      --editor-bg: #ffffff;
      --border-color: #ced4da;
      --button-bg: #007bff;
      --button-hover-bg: #0056b3;
      --header-bg: #343a40;
    }
    .dark-mode {
      --bg-color: #343a40;
      --text-color: #f8f9fa;
      --editor-bg: #495057;
      --border-color: #6c757d;
      --button-bg: #17a2b8;
      --button-hover-bg: #117a8b;
      --header-bg: #212529;
    }
    body {
      font-family: 'Segoe UI', system-ui, sans-serif;
      background: var(--bg-color);
      color: var(--text-color);
      margin: 0;
      transition: background 0.3s, color 0.3s;
      text-align: center;
    }
    header {
      background: var(--header-bg);
      color: #fff;
      padding: 1rem;
      display: flex;
      justify-content: space-between;
      align-items: center;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }
    .container {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 20px;
      height: calc(100vh - 150px);
      padding: 20px;
      max-width: 1600px;
      margin: 0 auto;
    }
    .editor-panel, .output-panel {
      background: var(--editor-bg);
      border: 1px solid var(--border-color);
      border-radius: 8px;
      padding: 1rem;
      display: flex;
      flex-direction: column;
      position: relative;
      box-shadow: 0 2px 6px rgba(0,0,0,0.1);
    }
    /* Notes name input */
    #notesName {
      width: 100%;
      padding: 0.5rem;
      margin-bottom: 1rem;
      border: 1px solid var(--border-color);
      border-radius: 4px;
      font-size: 14px;
    }
    textarea, #output {
      flex: 1;
      padding: 1rem;
      border: 1px solid var(--border-color);
      border-radius: 4px;
      font-family: 'Fira Code', monospace;
      font-size: 14px;
      background: var(--editor-bg);
      color: var(--text-color);
      resize: none;
      margin-bottom: 1rem;
      transition: background 0.3s, color 0.3s;
    }
    #output {
      white-space: pre-wrap;
      overflow-y: auto;
    }
    /* Brush button with emoji */
    .brush-button {
      position: absolute;
      top: 10px;
      right: 10px;
      background: var(--button-bg);
      border: none;
      color: #fff;
      border-radius: 50%;
      width: 30px;
      height: 30px;
      cursor: pointer;
      font-weight: bold;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: transform 0.3s;
    }
    .brush-button:hover {
      transform: scale(1.1);
    }
    /* Action buttons with emojis */
    #runButton, #saveNotesButton, #stopButton {
      background: var(--button-bg);
      color: #fff;
      border: none;
      padding: 12px 24px;
      border-radius: 4px;
      cursor: pointer;
      font-weight: 600;
      transition: background 0.3s, transform 0.3s;
      margin-top: 10px;
      margin-right: 10px;
    }
    #runButton:hover, #saveNotesButton:hover, #stopButton:hover {
      background: var(--button-hover-bg);
      transform: translateY(-2px);
    }
    /* Fade in animation for output */
    .fade-in {
      animation: fadeIn 0.5s ease-in;
    }
    @keyframes fadeIn {
      from { opacity: 0; }
      to { opacity: 1; }
    }
    @keyframes cleanEffect {
      0% { opacity: 1; }
      50% { opacity: 0.2; }
      100% { opacity: 1; }
    }
    .cleaning {
      animation: cleanEffect 0.5s ease;
    }
    .spinner {
      display: inline-block;
      width: 16px;
      height: 16px;
      border: 3px solid rgba(0, 0, 0, 0.2);
      border-top-color: #000;
      border-radius: 50%;
      animation: spin 0.8s linear infinite;
      vertical-align: middle;
      margin-right: 8px;
    }
    @keyframes spin {
      to { transform: rotate(360deg); }
    }
    /* Hidden input for language (set to Java) */
    #language {
      display: none;
    }
    /* Simplified Menu button with emoji */
    button.menu-btn {
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 10px 20px;
      font-size: 16px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      background: var(--button-bg);
      color: #fff;
      transition: background 0.3s, transform 0.3s;
      text-decoration: none;
    }
    button.menu-btn:hover {
      background: var(--button-hover-bg);
      transform: translateY(-2px);
    }
    button.menu-btn a {
      color: inherit;
      text-decoration: none;
    }
    button.menu-btn a:hover {
      text-decoration: underline;
    }
    footer {
      text-align: center;
      padding: 10px;
      background: var(--header-bg);
      color: #fff;
    }
  </style>
</head>
<body>
  <header>
    <h1>Java Editor</h1>
    <button class="menu-btn">
      <a href="../pages/code.php">Menu</a>
    </button>
    <button id="themeToggle">🌙</button>
  </header>
  <div class="container">
    <div class="editor-panel">
      <!-- Brush button to clear the code area with emoji -->
      
      <!-- Optional: Notes name input -->
      <input type="text" id="notesName" placeholder="Enter notes name (optional)..." />
      <!-- Code textarea with sample Java code -->
      <textarea id="codeArea" placeholder="Write your Java code here...">
public class Main {
    public static void main(String[] args) {
        System.out.println("Hello, world!");
    }
}
      </textarea>
      <!-- Brush button to clear the input area with emoji -->
      <button class="brush-button" style="top: 50%;" onclick="clearField('inputArea')">🖌️</button>
      <!-- Input textarea -->
      <textarea id="inputArea" placeholder="Enter input (if any)..."></textarea>
      <div style="display: flex; justify-content: flex-end;">
        <button id="stopButton">Stop</button>
        <button id="saveNotesButton">Save Notes 💾</button>
        <button id="runButton">Run Code ▶</button>
      </div>
      <!-- Hidden input for language (default set to Java) -->
      <input type="hidden" id="language" value="Java" />
    </div>
    <div class="output-panel">
      <!-- Brush button to clear the output area with emoji -->
      <button class="brush-button" onclick="clearField('output')">🖌️</button>
      <pre id="output"></pre>
    </div>
  </div>
  <footer>
    <p>© <?php echo date("Y"); ?> Online Code Editor</p>
  </footer>
  <!-- Include SweetAlert2 JS -->
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <script>
    document.addEventListener('DOMContentLoaded', () => {
      // Theme toggle functionality
      const themeToggle = document.getElementById('themeToggle');
      const body = document.body;
      themeToggle.addEventListener('click', () => {
        body.classList.toggle('dark-mode');
        const isDark = body.classList.contains('dark-mode');
        themeToggle.textContent = isDark ? '☀️' : '🌙';
        localStorage.setItem('theme', isDark ? 'dark' : 'light');
      });
      const savedTheme = localStorage.getItem('theme');
      if (savedTheme === 'dark') {
        body.classList.add('dark-mode');
        themeToggle.textContent = '☀️';
      }
      
      // Function to clear a field with a cleaning animation
      function clearField(id) {
        const element = document.getElementById(id);
        element.classList.add('cleaning');
        setTimeout(() => {
          element.value = '';
          element.textContent = '';
          element.classList.remove('cleaning');
        }, 300);
      }
      window.clearField = clearField; // Make it globally available
      
      // Global variable for aborting compile requests
      let currentCompilationController = null;
      
      // Run Code: compile and run the code (no login required)
      document.getElementById('runButton').addEventListener('click', (e) => {
        e.preventDefault();
        const outputElement = document.getElementById('output');
        const code = document.getElementById('codeArea').value;
        const input = document.getElementById('inputArea').value;
        
        if (!code.trim()) {
          outputElement.textContent = "Please write Java code first!";
          return;
        }
        
        if (currentCompilationController) {
          currentCompilationController.abort();
        }
        currentCompilationController = new AbortController();
        outputElement.innerHTML = '<span class="spinner"></span> Compiling and running...';
        
        fetch('java_compiler.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: `code=${encodeURIComponent(code)}&input=${encodeURIComponent(input)}`,
          signal: currentCompilationController.signal
        })
        .then(response => response.text())
        .then(data => {
          outputElement.textContent = data.trim();
          outputElement.classList.add('fade-in');
          setTimeout(() => outputElement.classList.remove('fade-in'), 500);
        })
        .catch(error => {
          if (error.name === 'AbortError') {
            outputElement.textContent = 'Compilation stopped.';
          } else {
            outputElement.textContent = `Error: ${error}`;
          }
        })
        .finally(() => {
          currentCompilationController = null;
        });
      });
      
      // Save Notes: uses SweetAlert2 popups for a smoother experience.
      const loggedIn = <?php echo json_encode($loggedIn); ?>;
      document.getElementById('saveNotesButton').addEventListener('click', async () => {
        if (!loggedIn) {
          await Swal.fire({
            icon: 'error',
            title: 'Not Logged In',
            text: 'You must be logged in to save notes.'
          });
          window.location.href = "../email/login.php";
          return;
        }
        const code = document.getElementById('codeArea').value.trim();
        if (code === "") {
          Swal.fire({
            icon: 'error',
            title: 'No Code',
            text: 'No code provided to save.'
          });
          return;
        }
        const outputText = document.getElementById('output').textContent.trim();
        if (outputText === "") {
          Swal.fire({
            icon: 'error',
            title: 'No Output',
            text: 'Please run the code before saving notes.'
          });
          return;
        }
        let notesName = document.getElementById('notesName').value.trim();
        if (notesName === "") {
          const { value: inputNotesName } = await Swal.fire({
            title: 'Enter a name for your note',
            input: 'text',
            inputPlaceholder: 'Note name',
            showCancelButton: true,
            inputValidator: (value) => {
              if (!value) {
                return 'Note name is required!';
              }
            }
          });
          if (!inputNotesName) {
            return;
          }
          notesName = inputNotesName;
        }
        const confirmResult = await Swal.fire({
          title: 'Confirm Save',
          text: `Are you sure you want to save note "${notesName}"?`,
          icon: 'question',
          showCancelButton: true,
          confirmButtonText: 'Yes, save it!',
          cancelButtonText: 'Cancel'
        });
        if (!confirmResult.isConfirmed) {
          return;
        }
        const language = document.getElementById('language').value || "Java";
        const data = `code=${encodeURIComponent(code)}&output=${encodeURIComponent(outputText)}&notesName=${encodeURIComponent(notesName)}&language=${encodeURIComponent(language)}`;
        
        Swal.fire({
          title: 'Saving note...',
          html: 'Please wait while your note is being saved.',
          didOpen: () => {
            Swal.showLoading();
          },
          allowOutsideClick: false,
          allowEscapeKey: false
        });
        
        try {
          const response = await fetch('../editors/save_notes.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: data
          });
          const result = await response.text();
          Swal.fire({
            icon: 'success',
            title: 'Note Saved',
            text: result.trim(),
            timer: 2000,
            showConfirmButton: false
          });
        } catch (error) {
          Swal.fire({
            icon: 'error',
            title: 'Save Failed',
            text: "Error saving note: " + error.message
          });
        }
      });
      
      // Stop Compilation: abort any ongoing compile request
      document.getElementById('stopButton').addEventListener('click', () => {
        if (currentCompilationController) {
          currentCompilationController.abort();
        }
      });
    });
  </script>
</body>
</html>
