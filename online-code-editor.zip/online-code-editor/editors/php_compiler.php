<?php
session_start();
header('Content-Type: text/plain');

// ================================================
// Security Warning: This executes arbitrary PHP code!
// Use Docker/sandboxing in production environments
// ================================================

// Configure PHP CLI path (adjust for your system)
$phpPath = 'C:\xampp\php\php.exe'; // Windows example
$code = $_POST['code'] ?? '';
$input = $_POST['input'] ?? '';

if (empty($code)) die("Error: No PHP code provided!");

// ================================================
// Write Temporary Files
// ================================================
$filename_code = "temp_script.php";
$filename_input = "temp_input.txt";

file_put_contents($filename_code, $code);
if (!empty($input)) file_put_contents($filename_input, $input);

// ================================================
// Execute PHP Code
// ================================================
$command = "$phpPath $filename_code";
if (!empty($input)) {
    // Windows: type, Linux: cat
    $command = "type $filename_input | $phpPath $filename_code";
}

$output = shell_exec("$command 2>&1");

// ================================================
// Cleanup & Output
// ================================================
@unlink($filename_code);
@unlink($filename_input);

echo trim($output) ?: "No output generated";
?>