<?php
session_start();
if (!isset($_SESSION['email'])) {
    echo "Error: You must be logged in to save notes.";
    exit();
}

// Database configuration
$servername = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "online_editor";

$conn = new mysqli($servername, $dbUsername, $dbPassword, $dbName);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Expecting POST variables: code, output, language, notesName
$code = $_POST["code"] ?? "";
$output = $_POST["output"] ?? "";
$language = $_POST["language"] ?? "";
$notesName = $_POST["notesName"] ?? "";

if (empty(trim($code)) || empty(trim($notesName))) {
    echo "Error: Code and note name are required.";
    exit();
}

$userEmail = $_SESSION['email'];
$date = date("Y-m-d H:i:s");

// Create a submission object.
$submission = array(
    "code" => $code,
    "language" => $language,
    "output" => $output,
    "date" => $date
);

// Check if a record with this Gmail and notesName already exists.
$sql = "SELECT id, submissions FROM saved_notes WHERE gmail = ? AND notesname = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $userEmail, $notesName);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // Record exists: append new submission.
    $row = $result->fetch_assoc();
    $submissions = json_decode($row['submissions'], true);
    if (!is_array($submissions)) {
        $submissions = array();
    }
    $submissions[] = $submission;
    $submissions_json = json_encode($submissions);
    $updateSql = "UPDATE saved_notes SET submissions = ? WHERE id = ?";
    $updateStmt = $conn->prepare($updateSql);
    $updateStmt->bind_param("si", $submissions_json, $row['id']);
    if ($updateStmt->execute()){
        echo "Note updated successfully.";
    } else {
        echo "Error updating note.";
    }
    $updateStmt->close();
} else {
    // No record exists: insert a new one.
    $submissions = array($submission);
    $submissions_json = json_encode($submissions);
    $insertSql = "INSERT INTO saved_notes (gmail, notesname, submissions) VALUES (?, ?, ?)";
    $insertStmt = $conn->prepare($insertSql);
    $insertStmt->bind_param("sss", $userEmail, $notesName, $submissions_json);
    if ($insertStmt->execute()){
        echo "Note saved successfully.";
    } else {
        echo "Error saving note.";
    }
    $insertStmt->close();
}
$conn->close();
?>
