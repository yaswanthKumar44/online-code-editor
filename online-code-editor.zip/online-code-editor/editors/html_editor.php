<?php
// public/editors/html_editor.php - HTML/CSS/JS Editor Page with dark/light themes, clear editors, and blue gradient background
session_start();
$loggedIn = isset($_SESSION['email']); // Logged-in status
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>HTML/CSS/JS Editor - Online Code Editor</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- SweetAlert2 CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
  <style>
    /* Simplified CSS Variables with background gradients */
    :root {
      --text-color: #212121;
      --editor-bg: #ffffff;
      --border-color: #e0e0e0;
      --button-bg: linear-gradient(135deg, #a1c4fd, #c2e9fb);
      --button-hover-bg: linear-gradient(135deg, #8eb6e3, #a3d8f0);
      --header-bg: linear-gradient(135deg, #003399, #000066);
    }
    .dark-mode {
      --bg-color: linear-gradient(135deg, #232526, #414345);
      --text-color: #f5f5f5;
      --editor-bg: #2d2d2d;
      --border-color: #555;
      --button-bg: linear-gradient(135deg, #667eea, #764ba2);
      --button-hover-bg: linear-gradient(135deg, #5b6ac7, #6b589b);
      --header-bg: linear-gradient(135deg, #1f1c2c, #928dab);
    }
    
    /* Basic Page Styling */
    body {
      font-family: 'Segoe UI', sans-serif;
      background: var(--bg-color);
      color: var(--text-color);
      margin: 0;
      transition: background 0.3s, color 0.3s;
      text-align: center;
    }
    
    /* Header with blue gradient background and overlay effects */
    header {
      background: var(--header-bg);
      color: white;
      padding: 1rem;
      display: flex;
      justify-content: space-between;
      align-items: center;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
      position: relative;
      z-index: 1;
    }
    /* Header overlay (optional) */
    header::before {
      content: "";
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: radial-gradient(circle, rgba(255,255,255,0.1) 20%, transparent 80%);
      pointer-events: none;
      z-index: -1;
    }
    
    /* Container grid for editor and output panels */
    .container {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 20px;
      padding: 20px;
      max-width: 1600px;
      margin: 0 auto;
      min-height: calc(100vh - 150px);
    }
    
    .editor-panel, .output-panel {
      background: var(--editor-bg);
      border: 1px solid var(--border-color);
      border-radius: 12px;
      padding: 1rem;
      display: flex;
      flex-direction: column;
      position: relative;
      box-shadow: 0 4px 12px rgba(0,0,0,0.05);
    }
    
    /* Notes name input */
    #notesName {
      width: 100%;
      padding: 0.5rem;
      margin-bottom: 1rem;
      border: 1px solid var(--border-color);
      border-radius: 8px;
      font-size: 14px;
    }
    
    /* Editor textareas and output area */
    textarea.editor {
      width: 100%;
      height: 300px;
      padding: 10px;
      margin-bottom: 10px;
      border: 1px solid var(--border-color);
      font-family: 'Fira Code', monospace;
      font-size: 14px;
      resize: vertical;
      border-radius: 5px;
      background: var(--editor-bg);
      color: var(--text-color);
      transition: background 0.3s, color 0.3s;
    }
    #output {
      width: 100%;
      height: 300px;
      padding: 10px;
      border: 1px solid var(--border-color);
      background-color: #f9f9f9;
      border-radius: 5px;
      font-family: 'Fira Code', monospace;
      font-size: 14px;
      white-space: pre-wrap;
      overflow-y: auto;
    }
    
    /* Brush button to clear fields */
    .brush-button {
      position: absolute;
      top: 10px;
      right: 10px;
      background: var(--button-bg);
      border: none;
      color: white;
      border-radius: 50%;
      width: 30px;
      height: 30px;
      cursor: pointer;
      font-weight: bold;
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 2px 8px rgba(0,0,0,0.2);
      transition: transform 0.3s;
    }
    .brush-button:hover {
      transform: scale(1.1);
    }
    
    /* Unified Button Styling */
    button {
      display: inline-flex;
      justify-content: center;
      align-items: center;
      padding: 12px 24px;
      font-size: 16px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      background: var(--button-bg);
      color: white;
      transition: background 0.3s, transform 0.3s;
      margin: 10px 5px;
    }
    button:hover {
      background: var(--button-hover-bg);
      transform: translateY(-2px);
    }
    button a {
      color: inherit;
      text-decoration: none;
    }
    button a:hover {
      text-shadow: 0px 0px 5px rgba(255,255,255,0.8);
    }
    
    /* Fade-in effect for output */
    .fade-in {
      animation: fadeIn 0.5s ease-in;
    }
    @keyframes fadeIn {
      from { opacity: 0; }
      to { opacity: 1; }
    }
    
    /* Cleaning animation for clearing fields */
    @keyframes cleanEffect {
      0% { opacity: 1; }
      50% { opacity: 0.2; }
      100% { opacity: 1; }
    }
    .cleaning {
      animation: cleanEffect 0.5s ease;
    }
    
    /* Spinner for loading indicator */
    .spinner {
      display: inline-block;
      width: 16px;
      height: 16px;
      border: 3px solid rgba(0,0,0,0.2);
      border-top-color: #000;
      border-radius: 50%;
      animation: spin 0.8s linear infinite;
      vertical-align: middle;
      margin-right: 8px;
    }
    @keyframes spin {
      to { transform: rotate(360deg); }
    }
    
    /* Hidden input for language */
    #language {
      display: none;
    }
  </style>
  <!-- SweetAlert2 JS -->
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <script>
    document.addEventListener('DOMContentLoaded', () => {
      // Theme toggle functionality
      const themeToggle = document.getElementById('themeToggle');
      const body = document.body;
      themeToggle.addEventListener('click', () => {
        body.classList.toggle('dark-mode');
        const isDark = body.classList.contains('dark-mode');
        themeToggle.textContent = isDark ? '☀️' : '🌙';
        localStorage.setItem('theme', isDark ? 'dark' : 'light');
      });
      if (localStorage.getItem('theme') === 'dark') {
        body.classList.add('dark-mode');
        themeToggle.textContent = '☀️';
      }
      
      // Function to clear a field with cleaning animation
      function clearField(id) {
        const element = document.getElementById(id);
        element.classList.add('cleaning');
        setTimeout(() => {
          if (element.tagName === 'TEXTAREA' || element.tagName === 'INPUT') {
            element.value = '';
          } else {
            element.textContent = '';
          }
          element.classList.remove('cleaning');
        }, 300);
      }
      window.clearField = clearField;
      
      // Function to switch between editor tabs
      function openTab(tabName) {
        document.getElementById('htmlEditor').style.display = 'none';
        document.getElementById('cssEditor').style.display = 'none';
        document.getElementById('jsEditor').style.display = 'none';
        if (tabName === 'html') {
          document.getElementById('htmlEditor').style.display = 'block';
        } else if (tabName === 'css') {
          document.getElementById('cssEditor').style.display = 'block';
        } else if (tabName === 'js') {
          document.getElementById('jsEditor').style.display = 'block';
        }
      }
      window.openTab = openTab;
      
      // Global variable for aborting run code requests
      let currentRunController = null;
      
      // Run Code: combine HTML, CSS, and JS code and output in iframe
      document.getElementById('runButton').addEventListener('click', (e) => {
        e.preventDefault();
        const htmlCode = document.getElementById('htmlEditor').value;
        const cssCode = document.getElementById('cssEditor').value;
        const jsCode = document.getElementById('jsEditor').value;
        const combinedCode = htmlCode + "\n<style>\n" + cssCode + "\n</style>\n<script>\n" + jsCode + "\n<\/script>";
        const iframe = document.getElementById('outputFrame');
        const iframeDoc = iframe.contentWindow.document;
        iframeDoc.open();
        iframeDoc.write(combinedCode);
        iframeDoc.close();
      });
      
      // Save Notes: using SweetAlert2 popups for a smooth experience.
      const loggedIn = <?php echo json_encode($loggedIn); ?>;
      document.getElementById('saveNotesButton').addEventListener('click', async () => {
        if (!loggedIn) {
          await Swal.fire({
            icon: 'error',
            title: 'Not Logged In',
            text: 'You must be logged in to save notes.'
          });
          window.location.href = "../email/login.php";
          return;
        }
        const htmlCode = document.getElementById('htmlEditor').value.trim();
        const cssCode = document.getElementById('cssEditor').value.trim();
        const jsCode = document.getElementById('jsEditor').value.trim();
        const code = htmlCode + "\n" + cssCode + "\n" + jsCode;
        if (code === "") {
          await Swal.fire({
            icon: 'error',
            title: 'No Code',
            text: 'No code provided to save.'
          });
          return;
        }
        let outputContent = "";
        try {
          outputContent = document.getElementById('outputFrame').contentWindow.document.body.textContent.trim();
        } catch (err) {
          outputContent = "";
        }
        if (outputContent === "") {
          await Swal.fire({
            icon: 'error',
            title: 'No Output',
            text: 'Please run the code before saving notes.'
          });
          return;
        }
        let notesName = document.getElementById('notesName').value.trim();
        if (notesName === "") {
          const { value: inputNotesName } = await Swal.fire({
            title: 'Enter a name for your note',
            input: 'text',
            inputPlaceholder: 'Note name',
            showCancelButton: true,
            inputValidator: (value) => {
              if (!value) {
                return 'Note name is required!';
              }
            }
          });
          if (!inputNotesName) {
            return;
          }
          notesName = inputNotesName;
        }
        const confirmResult = await Swal.fire({
          title: 'Confirm Save',
          text: `Are you sure you want to save note "${notesName}"?`,
          icon: 'question',
          showCancelButton: true,
          confirmButtonText: 'Yes, save it!',
          cancelButtonText: 'Cancel'
        });
        if (!confirmResult.isConfirmed) {
          return;
        }
        const language = document.getElementById('language').value || "HTML/CSS/JS";
        const data = `code=${encodeURIComponent(code)}&output=${encodeURIComponent(outputContent)}&notesName=${encodeURIComponent(notesName)}&language=${encodeURIComponent(language)}`;
        
        Swal.fire({
          title: 'Saving note...',
          html: 'Please wait while your note is being saved.',
          didOpen: () => {
            Swal.showLoading();
          },
          allowOutsideClick: false,
          allowEscapeKey: false
        });
        
        try {
          const response = await fetch('../editors/save_notes.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: data
          });
          const result = await response.text();
          Swal.fire({
            icon: 'success',
            title: 'Note Saved',
            text: result.trim(),
            timer: 2000,
            showConfirmButton: false
          });
        } catch (error) {
          Swal.fire({
            icon: 'error',
            title: 'Save Failed',
            text: "Error saving note: " + error.message
          });
        }
      });
      
      // Stop Run: abort any ongoing run request (if applicable)
      document.getElementById('stopButton').addEventListener('click', () => {
        if (currentRunController) {
          currentRunController.abort();
        }
      });
    });
  </script>
</head>
<body>
  <header class="blue-gradient-background">
    <h1>HTML/CSS/JS Editor</h1>
    <!-- Menu button: using a proper button element for navigation -->
    <button id="menuButton" onclick="window.location.href='../pages/code.php'">📋 Menu</button>
    <button id="themeToggle">🌙</button>
  </header>
  <div class="container">
    <div class="editor-panel">
      <div class="tabs" style="margin-bottom: 10px;">
        <button type="button" class="tab-button" onclick="openTab('html')">index.html</button>
        <button type="button" class="tab-button" onclick="openTab('css')">style.css</button>
        <button type="button" class="tab-button" onclick="openTab('js')">script.js</button>
      </div>
      <!-- Notes name field -->
      <input type="text" id="notesName" placeholder="Enter note name (optional)..." />
      <!-- HTML Editor with sample code -->
      <textarea id="htmlEditor" class="editor" placeholder="&lt;!DOCTYPE html&gt;
&lt;html lang=&quot;en&quot;&gt;
&lt;head&gt;
  &lt;meta charset=&quot;UTF-8&quot;&gt;
  &lt;title&gt;My Page&lt;/title&gt;
&lt;/head&gt;
&lt;body&gt;
  &lt;h1&gt;Hello, World!&lt;/h1&gt;
&lt;/body&gt;
&lt;/html&gt;">&lt;!DOCTYPE html&gt;
&lt;html lang=&quot;en&quot;&gt;
&lt;head&gt;
  &lt;meta charset=&quot;UTF-8&quot;&gt;
  &lt;title&gt;My Page&lt;/title&gt;
&lt;/head&gt;
&lt;body&gt;
  &lt;h1&gt;Hello, World!&lt;/h1&gt;
&lt;/body&gt;
&lt;/html&gt;</textarea>
      <!-- CSS Editor with sample code (initially hidden) -->
      <textarea id="cssEditor" class="editor" style="display:none;" placeholder="/* CSS styles go here */
body {
  background-color: #f4f4f4;
  font-family: Arial, sans-serif;
}">/* CSS styles go here */
body {
  background-color: #f4f4f4;
  font-family: Arial, sans-serif;
}</textarea>
      <!-- JS Editor with sample code (initially hidden) -->
      <textarea id="jsEditor" class="editor" style="display:none;" placeholder="// JavaScript code goes here
console.log('Hello, World!');">// JavaScript code goes here
console.log('Hello, World!');</textarea>
      <div style="display: flex; justify-content: flex-end;">
        <button id="stopButton">⏹️ Stop</button>
        <button id="saveNotesButton">💾 Save Notes</button>
        <button id="runButton">▶️ Run Code</button>
      </div>
      <!-- Hidden input for language -->
      <input type="hidden" id="language" value="HTML/CSS/JS" />
    </div>
    <div class="output-panel">
      <button class="brush-button" onclick="clearField('outputFrame')">🖌️</button>
      <iframe id="outputFrame" class="output-frame" style="width: 100%; height: 100%; border: none;"></iframe>
    </div>
  </div>
</body>
</html>
