<?php
session_start();
header('Content-Type: text/plain');

// ================================================
// 1. Configure Rscript Path (Using JDK R-4.4.2 Path)
// ================================================
$Rscript = '"C:\\Program Files\\R\\R-4.4.2\\bin\\Rscript.exe"'; // Adjust if needed

// ================================================
// 2. Validate Input
// ================================================
$code = $_POST['code'] ?? '';
$input = $_POST['input'] ?? '';

if (empty($code)) {
    die("Error: No R code submitted.");
}

// ================================================
// 3. Write Files
// ================================================
$filename_code = "main.R";      // R source file
$filename_input = "input.txt";   // File to capture input (if provided)

if (file_put_contents($filename_code, $code) === false) {
    die("Error: Unable to write R code to file.");
}

if (!empty($input)) {
    if (file_put_contents($filename_input, $input) === false) {
        die("Error: Unable to write input to file.");
    }
}

// ================================================
// 4. Run R Code (Capture Output and Errors)
// ================================================
if (!empty($input)) {
    // For Windows, pipe input using 'type'
    $runCommand = "type $filename_input | $Rscript $filename_code 2>&1";
} else {
    $runCommand = "$Rscript $filename_code 2>&1";
}

$output = shell_exec($runCommand);

// ================================================
// 5. Display Output
// ================================================
if ($output === null) {
    echo "No output or runtime error.";
} else {
    echo trim($output);
}

// ================================================
// 6. Cleanup Files
// ================================================
$filesToDelete = [$filename_code, $filename_input];
foreach ($filesToDelete as $file) {
    if (file_exists($file)) {
        @unlink($file);
    }
}
?>
