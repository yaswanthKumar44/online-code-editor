<?php
session_start();
header('Content-Type: text/plain');

// ================================================
// 1. Configure Python Path
// ================================================
putenv("PATH=C:\\Users\\yashy\\AppData\\Local\\Programs\\Python\\Python312;" . getenv("PATH"));

// ================================================
// 2. Validate Input
// ================================================
$code = $_POST['code'] ?? '';
$input = $_POST['input'] ?? '';

if (empty($code)) {
    die("Error: No Python code submitted.");
}

// ================================================
// 3. Write Files
// ================================================
$filename_code = "main.py";      // Python source file
$filename_input = "input.txt";    // Input file (if provided)

if (file_put_contents($filename_code, $code) === false) {
    die("Error: Unable to write Python code to file.");
}

if (!empty($input)) {
    if (file_put_contents($filename_input, $input) === false) {
        die("Error: Unable to write input to file.");
    }
}

// ================================================
// 4. Run Python Code (Capture Output and Errors)
// ================================================
// Use the full path from the PATH variable, now that it’s set
// On Windows, if you need to pipe input, you can use the "type" command.
if (!empty($input)) {
    // For Windows, pipe the input file into the python command
    $runCommand = "type $filename_input | python $filename_code 2>&1";
} else {
    $runCommand = "python $filename_code 2>&1";
}

$output = shell_exec($runCommand);

// ================================================
// 5. Display Output
// ================================================
if ($output === null) {
    echo "No output or runtime error.";
} else {
    echo trim($output);
}

// ================================================
// 6. Cleanup Files
// ================================================
$filesToDelete = [$filename_code, $filename_input];
foreach ($filesToDelete as $file) {
    if (file_exists($file)) {
        @unlink($file);
    }
}
?>
