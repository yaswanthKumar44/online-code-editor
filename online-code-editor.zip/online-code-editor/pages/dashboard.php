<?php
session_start();
if (!isset($_SESSION['email'])) { 
    header("Location: ../email/login.php");
    exit();
}

// Database configuration
$servername = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "online_editor";

$conn = new mysqli($servername, $dbUsername, $dbPassword, $dbName);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve the profile photo from the users table using the email from session
$email = $_SESSION['email'];
$stmt = $conn->prepare("SELECT profile_photo FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->bind_result($profile_photo);
$stmt->fetch();
$stmt->close();
$conn->close();

// If profile photo is not available, use a default image URL
$profileImage = !empty($profile_photo) ? $profile_photo : "https://th.bing.com/th/id/OIP.o_O4ilJOBMhDHhZy7oZc-AAAAA?rs=1&pid=ImgDetMain";
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Online Code Editor - Home</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- Original Dashboard Styles -->
  <style>
    /* Global CSS Variables for themes */
    :root {
      --primary-color: #00ff00;
      --bg-color: #000000;
      --border-color: #00ff00;
      --shadow-glow: 0 0 10px #00ff00;
      --text-glow: 0 0 5px #00ff00;
      --gradient-start: rgba(44,62,80,0.4);
      --gradient-end: rgba(52,73,94,0.4);
      --particle-color: rgba(255, 255, 255, 0.8);
      --angle: 45deg;
    }
    .light-theme {
      /* Light theme toned down with softer colors */
      --primary-color: #333333;
      --bg-color: #f0f0f0;
      --border-color: #333333;
      --shadow-glow: none;
      --text-glow: none;
      --gradient-start: rgba(240,240,240,0.5);
      --gradient-end: rgba(200,200,200,0.5);
      --particle-color: rgba(50, 50, 50, 0.5);
    }
    /* Global Reset */
    *, *::before, *::after {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    html, body {
      width: 100%;
      height: 100%;
      font-family: 'Courier New', monospace;
      overflow: hidden;
      background-color: var(--bg-color);
      color: var(--primary-color);
    }
    body {
      position: relative;
      cursor: none; /* Hide default cursor */
    }
    /* Background Image */
    .background-image {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background-image: url('https://www.shutterstock.com/image-photo/analysts-use-computers-analyze-statistical-600nw-2345717223.jpg');
      background-size: cover;
      background-position: center;
      z-index: -4;
      pointer-events: none;
    }
    /* Gradient Overlay */
    .gradient-overlay {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: linear-gradient(var(--angle), var(--gradient-start), var(--gradient-end));
      animation: gradientShift 15s ease infinite;
      z-index: -2;
      pointer-events: none;
    }
    @keyframes gradientShift {
      0% { background-position: 0% 50%; }
      50% { background-position: 100% 50%; }
      100% { background-position: 0% 50%; }
    }
    /* Particle Canvas for Background Animation */
    #particle-canvas {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      z-index: -1;
      pointer-events: none;
    }
    /* Dashboard Container */
    .dashboard-container {
      position: relative;
      z-index: 1;
      width: 90%;
      max-width: 900px;
      background-color: rgba(0, 0, 0, 0.6);
      border: 2px solid var(--border-color);
      border-radius: 10px;
      padding: 40px;
      box-shadow: 0 4px 8px rgba(0,0,0,0.5), var(--shadow-glow);
      text-align: center;
      margin: 5% auto;
      animation: fadeIn 1s ease-in-out;
    }
    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(-20px); }
      to { opacity: 1; transform: translateY(0); }
    }
    .dashboard-container h2 {
      margin-bottom: 20px;
      text-shadow: var(--text-glow);
    }
    .dashboard-container p {
      margin-bottom: 30px;
    }
    /* Dashboard Options Grid */
    .dashboard-options {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 20px;
      justify-content: center;
      align-items: center;
      margin-top: 20px;
    }
    .option {
      background: rgba(0, 0, 0, 0.8);
      padding: 20px;
      border: 1px solid var(--border-color);
      border-radius: 10px;
      cursor: pointer;
      transition: background 0.3s ease, transform 0.3s ease, box-shadow 0.3s ease;
      text-align: center;
      position: relative;
      overflow: hidden;
      box-shadow: var(--shadow-glow);
    }
    .option::before {
      content: "";
      position: absolute;
      top: -50%;
      left: -50%;
      width: 200%;
      height: 200%;
      background: rgba(255, 255, 255, 0.1);
      border-radius: 50%;
      transition: transform 0.5s ease;
      z-index: 1;
    }
    .option:hover::before {
      transform: rotate(45deg);
    }
    .option:hover {
      background: rgba(0, 0, 0, 0.9);
      transform: translateY(-5px);
    }
    a {
      text-decoration: none;
      color: var(--primary-color);
      display: block;
      font-size: 1.1em;
    }
    /* Custom Cursor */
    #custom-cursor {
      position: fixed;
      top: 0;
      left: 0;
      width: 12px;
      height: 12px;
      background-color: #ff7979;
      border-radius: 50%;
      pointer-events: none;
      z-index: 10000;
      transform: translate(-50%, -50%);
      box-shadow: 0 0 8px rgba(255,121,121,0.8);
    }
    /* Spark effect for cursor */
    .spark {
      position: fixed;
      width: 10px;
      height: 10px;
      background: radial-gradient(circle, #fff, #000);
      border-radius: 50%;
      pointer-events: none;
      z-index: 9999;
      opacity: 1;
      animation: sparkFade 1s forwards;
    }
    @keyframes sparkFade {
      to { opacity: 0; transform: scale(3); }
    }
    /* Profile Photo */
    .profile-photo {
      width: 100px;
      height: 100px;
      border-radius: 50%;
      object-fit: cover;
      margin: 0 auto 20px auto;
      display: block;
      border: 3px solid var(--border-color);
    }
    footer {
      position: fixed;
      bottom: 0;
      width: 100%;
      background-color: #111;
      color: var(--primary-color);
      padding: 10px;
      text-align: center;
      z-index: 1;
    }
  </style>
  
  <!-- Additional CSS -->
  <style>
    /* Reset default browser styles for consistency */
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    
    body {
      /* Apply the gradient from the image */
      background: linear-gradient(to bottom right, #ADD8E6, #4B0082);
      font-family: sans-serif;
      color: white;
      line-height: 1.6;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
    }
    
    /* Header Styles */
    header {
      text-align: center;
      padding: 2rem 1rem;
      background-color: rgba(0, 0, 0, 0.2);
    }
    
    header h1 {
      font-size: 2.5rem;
      margin-bottom: 1rem;
    }
    
    header nav ul {
      list-style: none;
      display: flex;
      justify-content: center;
    }
    
    header nav ul li {
      margin: 0 1rem;
    }
    
    header nav ul li a {
      color: #87CEEB;
      text-decoration: none;
      padding: 0.5rem 1rem;
      border-radius: 5px;
      transition: background-color 0.3s ease;
    }
    
    header nav ul li a:hover {
      background-color: rgba(255, 255, 255, 0.1);
    }
    
    /* Main Content Styles */
    main {
      flex-grow: 1;
      padding: 2rem 1rem;
      display: flex;
      justify-content: center;
      align-items: center;
    }
    
    .content-container {
      background-color: rgba(255, 255, 255, 0.1);
      padding: 3rem;
      border-radius: 10px;
      max-width: 800px;
      width: 100%;
    }
    
    .content-container h2 {
      font-size: 2rem;
      margin-bottom: 1.5rem;
      text-align: center;
    }
    
    .content-container p {
      margin-bottom: 1.5rem;
    }
    
    .content-container button {
      background-color: #9370DB;
      color: white;
      padding: 1rem 2rem;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      font-size: 1rem;
      transition: background-color 0.3s ease;
    }
    
    .content-container button:hover {
      background-color: #800080;
    }
    
    /* Footer Styles */
    footer {
      text-align: center;
      padding: 1rem;
      background-color: rgba(0, 0, 0, 0.2);
    }
    
    footer p {
      font-size: 0.9rem;
    }
    
    /* Responsive Design Adjustments */
    @media (max-width: 768px) {
      header nav ul {
        flex-direction: column;
        align-items: center;
      }
    
      header nav ul li {
        margin: 0.5rem 0;
      }
    
      .content-container {
        padding: 2rem;
      }
    }
  </style>
  
  <script>
    // Update gradient angle based on mouse movement
    document.addEventListener("mousemove", (e) => {
      const x = e.clientX;
      const y = e.clientY;
      const width = window.innerWidth;
      const height = window.innerHeight;
      const angle = Math.atan2(y - height / 2, x - width / 2) * 180 / Math.PI;
      document.body.style.setProperty('--angle', angle + 'deg');
    });

    // Toggle fullscreen mode when fullscreen option is clicked
    function toggleFullScreen() {
      if (!document.fullscreenElement) {
        document.documentElement.requestFullscreen().catch(err => {
          console.log(`Error attempting fullscreen: ${err.message}`);
        });
      } else {
        document.exitFullscreen();
      }
    }

    // Toggle dark/light theme and save preference in localStorage
    function toggleTheme() {
      document.body.classList.toggle('light-theme');
      if(document.body.classList.contains('light-theme')) {
        localStorage.setItem('theme', 'light');
      } else {
        localStorage.setItem('theme', 'dark');
      }
    }
    window.addEventListener('DOMContentLoaded', () => {
      if(localStorage.getItem('theme') === 'light'){
        document.body.classList.add('light-theme');
      }
    });
  </script>
</head>
<body>
  <!-- Background Image -->
  <div class="background-image"></div>
  <!-- Gradient Overlay -->
  <div class="gradient-overlay"></div>
  <!-- Particle Canvas for Background Animation -->
  <canvas id="particle-canvas"></canvas>
  
  <!-- Custom Cursor Element -->
  <div id="custom-cursor"></div>
  
  <div class="dashboard-container">
    <img src="<?= $profileImage ?>?v=<?= time() ?>" alt="Profile Photo" class="profile-photo">
    <h2>Welcome to your Dashboard 🚀</h2>
    <p>Logged in as: <?php echo $_SESSION['email']; ?></p>
    <div class="dashboard-options">
      <a href="profile.php"><div class="option">Profile 👤</div></a>
      <a href="code.php"><div class="option">Code Lab 💻</div></a>
      <a href="view_saved_notes.php"><div class="option">Notes 📝</div></a>
      <a href="logout.php"><div class="option">Logout 🚪</div></a>
      <div class="option" onclick="toggleFullScreen()">Fullscreen 🖥️</div>
      <div class="option" onclick="toggleTheme()">Toggle Theme 🌗</div>
    </div>
  </div>
  
  <footer>
    <p>© <?php echo date("Y"); ?> Online Code Editor</p>
  </footer>
  
  <script>
    // Custom Cursor and Spark Effects
    const customCursor = document.getElementById('custom-cursor');
    document.addEventListener('mousemove', (e) => {
      customCursor.style.top = `${e.clientY}px`;
      customCursor.style.left = `${e.clientX}px`;
  
      const spark = document.createElement('div');
      spark.classList.add('spark');
      spark.style.top = `${e.clientY}px`;
      spark.style.left = `${e.clientX}px`;
      document.body.appendChild(spark);
      setTimeout(() => {
        spark.remove();
      }, 1000);
    });
  
    // Particle Animation Script
    const canvas = document.getElementById('particle-canvas');
    const ctx = canvas.getContext('2d');
    let particlesArray = [];
    const numberOfParticles = 100;
  
    // Set canvas dimensions to window dimensions
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
  
    // Particle constructor
    class Particle {
      constructor() {
        this.x = Math.random() * canvas.width;
        this.y = Math.random() * canvas.height;
        this.size = Math.random() * 2 + 1;
        this.speedX = (Math.random() * 0.5) - 0.25;
        this.speedY = (Math.random() * 0.5) - 0.25;
      }
      update() {
        this.x += this.speedX;
        this.y += this.speedY;
        if (this.x < 0) this.x = canvas.width;
        if (this.x > canvas.width) this.x = 0;
        if (this.y < 0) this.y = canvas.height;
        if (this.y > canvas.height) this.y = 0;
      }
      draw(color) {
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
        ctx.fillStyle = color;
        ctx.fill();
      }
    }
  
    function initParticles() {
      particlesArray = [];
      for (let i = 0; i < numberOfParticles; i++) {
        particlesArray.push(new Particle());
      }
    }
    initParticles();
  
    function animateParticles() {
      const currentParticleColor = getComputedStyle(document.body).getPropertyValue('--particle-color');
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      particlesArray.forEach(particle => {
        particle.update();
        particle.draw(currentParticleColor);
      });
      requestAnimationFrame(animateParticles);
    }
    animateParticles();
  
    window.addEventListener('resize', function(){
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
      initParticles();
    });
  </script>
</body>
</html>
