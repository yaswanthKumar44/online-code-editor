<?php
session_start();
date_default_timezone_set("Asia/Kolkata"); // Set correct timezone

// Database configuration
$servername = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "online_editor";

$conn = new mysqli($servername, $dbUsername, $dbPassword, $dbName);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$message = "";
$showProfileForm = false;

// Function to validate strong password
function isStrongPassword($password) {
    return preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/', $password);
}

// Fetch user data
if (isset($_SESSION['email'])) {
    $email = $_SESSION['email'];
    $stmt = $conn->prepare("SELECT id, name, email, profile_photo, gender, dob, phone_number, role FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($id, $name, $email, $profile_photo, $gender, $dob, $phone_number, $role);
        $stmt->fetch();
        $showProfileForm = true;
    } else {
        $message = "<span class='error'>User not found.</span>";
    }
    $stmt->close();
} else {
    $message = "<span class='error'>Session expired. Please login again.</span>";
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['update_profile'])) {
        if (isset($_SESSION['email'])) {
            $user_id = $_POST['user_id'];
            $name = $_POST['name'];
            // Email remains unchanged (read-only)
            $gender = $_POST['gender'];
            $dob = $_POST['dob'];
            $phone = $_POST['phone'];
            $role = $_POST['role'];
            $profile_photo_file = $_FILES['profile_photo'];

            // Validate mobile number: exactly 10 digits
            if (!preg_match('/^\d{10}$/', $phone)) {
                $message = "<span class='error'>Mobile number must be exactly 10 digits.</span>";
            } else {
                $birthDate = new DateTime($dob);
                $currentDate = new DateTime();
                $age = $birthDate->diff($currentDate)->y;

                if ($age < 18 || $age > 100) {
                    $message = "<span class='error'>Age must be between 18 and 100 years.</span>";
                } else {
                    // Handle file upload if provided
                    if ($profile_photo_file['size'] > 0) {
                        $target_dir = "uploads/";
                        if (!is_dir($target_dir)) {
                            if (!mkdir($target_dir, 0755, true)) {
                                $message = "<span class='error'>Failed to create uploads directory.</span>";
                                $conn->close();
                                exit();
                            }
                        }

                        $target_file = $target_dir . basename($profile_photo_file["name"]);
                        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

                        // Check if file is an image
                        $check = getimagesize($profile_photo_file["tmp_name"]);
                        if ($check !== false) {
                            if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg") {
                                $message = "<span class='error'>Sorry, only JPG, JPEG, PNG files are allowed.</span>";
                            } else {
                                $new_filename = uniqid() . "." . $imageFileType;
                                $target_file = $target_dir . $new_filename;

                                if (move_uploaded_file($profile_photo_file["tmp_name"], $target_file)) {
                                    $stmt = $conn->prepare("UPDATE users SET name = ?, profile_photo = ?, gender = ?, dob = ?, phone_number = ?, role = ? WHERE id = ?");
                                    $stmt->bind_param("ssssssi", $name, $target_file, $gender, $dob, $phone, $role, $user_id);
                                } else {
                                    $message = "<span class='error'>Sorry, there was an error uploading your file.</span>";
                                }
                            }
                        } else {
                            $message = "<span class='error'>File is not an image.</span>";
                        }
                    } else {
                        $stmt = $conn->prepare("UPDATE users SET name = ?, gender = ?, dob = ?, phone_number = ?, role = ? WHERE id = ?");
                        $stmt->bind_param("sssssi", $name, $gender, $dob, $phone, $role, $user_id);
                    }

                    if (isset($stmt) && $stmt->execute()) {
                        $message = "<span class='success'>Profile updated successfully!</span>";
                    } else {
                        $error = isset($stmt) ? $stmt->error : "";
                        $message = "<span class='error'>Error updating profile: " . $error . "</span>";
                    }
                    if (isset($stmt)) {
                        $stmt->close();
                    }
                }
            }
        } else {
            $message = "<span class='error'>Session expired. Please login again.</span>";
        }
    }

    // Handle password update if new password is provided
    if (!empty($_POST['password']) || !empty($_POST['confirm_password'])) {
        $password = $_POST['password'];
        $confirm_password = $_POST['confirm_password'];

        if ($password !== $confirm_password) {
            $message .= "<span class='error'>Passwords do not match.</span>";
        } elseif (!isStrongPassword($password)) {
            $message .= "<span class='error'>Password does not meet the strength requirements.</span>";
        } else {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $stmt_password = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
            $stmt_password->bind_param("si", $hashed_password, $user_id);

            if ($stmt_password->execute()) {
                $message .= "<span class='success'>Password updated successfully!</span>";
            } else {
                $message .= "<span class='error'>Error updating password: " . $stmt_password->error . "</span>";
            }
            $stmt_password->close();
        }
    }

    // Re-fetch updated user data so that new profile data is loaded immediately
    if (isset($_SESSION['email'])) {
        $email = $_SESSION['email'];
        $stmt = $conn->prepare("SELECT id, name, email, profile_photo, gender, dob, phone_number, role FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows > 0) {
            $stmt->bind_result($id, $name, $email, $profile_photo, $gender, $dob, $phone_number, $role);
            $stmt->fetch();
        }
        $stmt->close();
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Update Profile</title>
  <style>
    :root {
      --bg-gradient: linear-gradient(to bottom, #2c3e50, #34495e);
      --primary-color: #ecf0f1;
      --input-bg: rgba(255, 255, 255, 0.1);
      --input-border: rgba(255, 255, 255, 0.3);
      --input-text: #ffffff;
      --container-bg: rgba(0, 0, 0, 0.2);
      --button-bg: rgb(11, 120, 236);
      --button-hover-bg: rgb(9, 63, 225);
      --error-color: rgba(74, 8, 1, 0.95);
      --success-color: rgb(9, 47, 2);
      --label-color: #ffffff;
    }
    .light-theme {
      --bg-gradient: #f0f0f0;
      --primary-color: #333333;
      --input-bg: rgba(0, 0, 0, 0.1);
      --input-border: rgba(0, 0, 0, 0.3);
      --input-text: #333333;
      --container-bg: rgba(255, 255, 255, 0.8);
      --button-bg: #007BFF;
      --button-hover-bg: #0056b3;
      --error-color: #a00;
      --success-color: #0a0;
      --label-color: #333333;
    }
    body {
      margin: 0;
      padding: 0;
      font-family: sans-serif;
      background: var(--bg-gradient);
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
      color: var(--primary-color);
    }
    .theme-toggle {
      position: fixed;
      top: 10px;
      right: 10px;
      padding: 8px 16px;
      background-color: var(--button-bg);
      border: none;
      border-radius: 5px;
      color: var(--primary-color);
      cursor: pointer;
      transition: background-color 0.3s;
    }
    .theme-toggle:hover {
      background-color: var(--button-hover-bg);
    }
    .profile-container {
      width: 90%;
      max-width: 600px;
      background-color: var(--container-bg);
      border-radius: 10px;
      padding: 40px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    }
    h2 {
      text-align: center;
      color: var(--primary-color);
      margin-bottom: 20px;
    }
    hr {
      border: 1px solid var(--input-border);
      margin-bottom: 30px;
    }
    .input-group {
      margin-bottom: 20px;
    }
    .input-group label {
      display: block;
      color: var(--label-color);
      margin-bottom: 5px;
    }
    .input-group input, .input-group select {
      width: calc(100% - 22px);
      padding: 10px;
      border: 1px solid var(--input-border);
      border-radius: 5px;
      background-color: var(--input-bg);
      color: var(--input-text);
    }
    .input-group input::placeholder {
      color: var(--input-text);
    }
    .profile-button {
      display: block;
      width: 100%;
      padding: 12px;
      background-color: var(--button-bg);
      color: var(--primary-color);
      border: none;
      border-radius: 5px;
      cursor: pointer;
      font-size: 16px;
      transition: background-color 0.3s ease;
    }
    .profile-button:hover {
      background-color: var(--button-hover-bg);
    }
    .message {
      margin: 10px 0;
    }
    .success {
      color: var(--success-color);
      font-weight: bold;
    }
    .error {
      color: var(--error-color);
      font-weight: bold;
    }
    .profile-photo {
      width: 150px;
      height: 150px;
      border-radius: 50%;
      object-fit: cover;
      margin: 0 auto 20px auto;
      display: block;
    }
    .role-label {
      color: var(--label-color);
    }
    .button {
      display: inline-block;
      padding: 10px 20px;
      font-size: 16px;
      color: var(--primary-color);
      background-color: var(--button-bg);
      text-align: center;
      text-decoration: none;
      border-radius: 5px;
      transition: background-color 0.3s;
    }
    .button:hover {
      background-color: var(--button-hover-bg);
    }
  </style>
  <!-- Include SweetAlert2 JS -->
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <script>
    // Function to preview the newly uploaded photo
    function previewPhoto(input) {
      if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = function(e) {
          document.getElementById('photoPreview').src = e.target.result;
        }
        reader.readAsDataURL(input.files[0]);
      }
    }
    
    function checkPasswordRequirements(password) {
      const requirements = {
        length: password.length >= 8,
        uppercase: /[A-Z]/.test(password),
        lowercase: /[a-z]/.test(password),
        number: /\d/.test(password),
        special: /[!@#$%^&*]/.test(password),
      };

      const requirementsMessage = document.getElementById("password_requirements_message");
      let html = "<ul>";
      for (const [key, value] of Object.entries(requirements)) {
        html += `<li style="color: ${value ? 'var(--success-color)' : 'var(--error-color)'};">${key.charAt(0).toUpperCase() + key.slice(1)}: ${value ? '✔️' : '❌'}</li>`;
      }
      html += "</ul>";
      requirementsMessage.innerHTML = html;
    }

    function validatePassword() {
      const password = document.getElementById("password").value;
      const confirmPassword = document.getElementById("confirm_password").value;
      const matchMessage = document.getElementById("password_match_message");

      if (password !== confirmPassword) {
        matchMessage.textContent = "Passwords do not match.";
        matchMessage.style.color = "var(--error-color)";
      } else {
        matchMessage.textContent = "Passwords match.";
        matchMessage.style.color = "var(--success-color)";
      }

      checkPasswordRequirements(password);
    }

    function togglePasswordVisibility() {
      const passwordField = document.getElementById("password");
      const confirmPasswordField = document.getElementById("confirm_password");
      const passwordToggle = document.getElementById("passwordToggle");
      if (passwordField.type === "password") {
        passwordField.type = "text";
        confirmPasswordField.type = "text";
        passwordToggle.textContent = "Hide Password";
      } else {
        passwordField.type = "password";
        confirmPasswordField.type = "password";
        passwordToggle.textContent = "Show Password";
      }
    }

    function toggleTheme() {
      document.body.classList.toggle("light-theme");
      if(document.body.classList.contains("light-theme")){
        localStorage.setItem("theme", "light");
      } else {
        localStorage.setItem("theme", "dark");
      }
    }

    document.addEventListener("DOMContentLoaded", function() {
      if(localStorage.getItem("theme") === "light"){
        document.body.classList.add("light-theme");
      }
    });
  </script>
</head>
<body>
  <button class="theme-toggle" onclick="toggleTheme()">Toggle Theme</button>
  <div class="profile-container">
    <a href="dashboard.php" class="button">Go to Dashboard</a>
    <h2>Update Profile</h2>
    <hr>
    <?php if ($message): ?>
      <script>
        document.addEventListener('DOMContentLoaded', function() {
            Swal.fire({
                icon: <?php echo (strpos($message, 'success') !== false ? "'success'" : "'error'"); ?>,
                title: <?php echo (strpos($message, 'success') !== false ? "'Success'" : "'Error'"); ?>,
                html: '<?php echo addslashes($message); ?>',
                timer: 3000,
                showConfirmButton: false,
                animation: true
            });
        });
      </script>
    <?php endif; ?>
    <?php if ($showProfileForm): ?>
      <!-- Photo preview: if no photo, use default image -->
      <img id="photoPreview" src="<?= !empty($profile_photo) ? $profile_photo . '?v=' . time() : 'https://th.bing.com/th/id/OIP.o_O4ilJOBMhDHhZy7oZc-AAAAA?rs=1&pid=ImgDetMain' ?>" alt="Profile Photo" class="profile-photo">
      <form method="POST" enctype="multipart/form-data">
        <input type="hidden" name="user_id" value="<?php echo $id; ?>">
        <div class="input-group">
          <label for="name">Name</label>
          <input type="text" id="name" name="name" value="<?php echo $name; ?>" required>
        </div>
        <div class="input-group">
          <label for="email">Email</label>
          <input type="email" id="email" name="email" value="<?php echo $email; ?>" required readonly>
        </div>
        <div class="input-group">
          <label for="gender">Gender</label>
          <select id="gender" name="gender" required>
            <option value="Male" <?php echo ($gender == "Male") ? 'selected' : ''; ?>>Male</option>
            <option value="Female" <?php echo ($gender == "Female") ? 'selected' : ''; ?>>Female</option>
            <option value="Other" <?php echo ($gender == "Other") ? 'selected' : ''; ?>>Other</option>
          </select>
        </div>
        <div class="input-group">
          <label for="dob">Date of Birth</label>
          <input type="date" id="dob" name="dob" value="<?php echo $dob; ?>" required>
        </div>
        <div class="input-group">
          <label for="phone">Mobile Number</label>
          <!-- Limit phone number to 10 digits -->
          <input type="text" id="phone" name="phone" value="<?php echo $phone_number; ?>" required pattern="\d{10}" maxlength="10" placeholder="Enter 10-digit mobile number">
        </div>
        <div class="input-group">
          <label for="profile_photo">Profile Photo</label>
          <input type="file" id="profile_photo" name="profile_photo" accept="image/*" onchange="previewPhoto(this)">
        </div>
        <div class="input-group">
          <label for="role">Role</label>
          <select id="role" name="role" required>
            <option value="Student" <?php echo ($role == "Student") ? 'selected' : ''; ?>>Student</option>
            <option value="Faculty" <?php echo ($role == "Faculty") ? 'selected' : ''; ?>>Faculty</option>
            <option value="Other" <?php echo ($role == "Other") ? 'selected' : ''; ?>>Other</option>
          </select>
        </div>
        <div class="input-group">
          <label for="password">New Password (leave blank if you don't want to change)</label>
          <input type="password" id="password" name="password" onkeyup="validatePassword()" placeholder="At least 8 characters with a mix of letters, numbers, and symbols.">
        </div>
        <div class="input-group">
          <label for="confirm_password">Confirm Password</label>
          <input type="password" id="confirm_password" name="confirm_password" onkeyup="validatePassword()">
          <span id="password_match_message" class="message"></span>
        </div>
        <div id="password_requirements_message" class="message"></div>
        <button type="button" onclick="togglePasswordVisibility()" id="passwordToggle">Show Password</button>
        <button type="submit" name="update_profile" class="profile-button">Update Profile</button>
      </form>
    <?php endif; ?>
  </div>
</body>
</html>
