<?php
session_start();
if (!isset($_SESSION['email'])) {
    header("Location: ../email/login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] != 'POST') {
    die("Invalid request method.");
}

if (!isset($_POST['id'])) {
    die("Note ID not provided.");
}

$noteId = intval($_POST['id']);

$servername = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "online_editor";

$conn = new mysqli($servername, $dbUsername, $dbPassword, $dbName);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$userEmail = $_SESSION['email'];
$sql = "DELETE FROM saved_notes WHERE id = ? AND gmail = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("is", $noteId, $userEmail);
if ($stmt->execute()) {
    // Redirect back with a success flag to trigger the popup message
    header("Location: view_saved_notes.php?delete=success");
} else {
    echo "Error deleting note.";
}
$stmt->close();
$conn->close();
?>
