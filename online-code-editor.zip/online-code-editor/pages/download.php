<?php
session_start();
if (!isset($_SESSION['email'])) {
    header("Location: ../email/login.php");
    exit();
}

if (!isset($_GET['id'], $_GET['format'])) {
    die("Parameters missing.");
}

$noteId = intval($_GET['id']);
$format = $_GET['format']; // Expected: pdf or word

$servername = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "online_editor";

$conn = new mysqli($servername, $dbUsername, $dbPassword, $dbName);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$userEmail = $_SESSION['email'];
$sql = "SELECT * FROM saved_notes WHERE id = ? AND gmail = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("is", $noteId, $userEmail);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows == 0) {
    die("Note not found or access denied.");
}
$note = $result->fetch_assoc();
$stmt->close();
$conn->close();

// Prepare content
$content = "Note: " . $note['notesname'] . "\n\n";
$submissions = json_decode($note['submissions'], true);
if (is_array($submissions)) {
    foreach ($submissions as $submission) {
        $content .= "Date: " . $submission['date'] . "\n";
        $content .= "Language: " . $submission['language'] . "\n";
        $content .= "Code:\n" . $submission['code'] . "\n";
        $content .= "Output:\n" . $submission['output'] . "\n";
        $content .= "-------------------------\n";
    }
} else {
    $content .= "No submissions found.";
}

if ($format === "pdf") {
    // PDF export using FPDF
    require('../fpdf/fpdf.php');
    $pdf = new FPDF();
    $pdf->AddPage();
    $pdf->SetFont('Arial','',12);
    $pdf->MultiCell(0,10, $content);
    
    header('Content-Type: application/pdf');
    header('Content-Disposition: attachment; filename="note_'.$noteId.'.pdf"');
    $pdf->Output('D', "note_{$noteId}.pdf");
    exit();
} elseif ($format === "word") {
    // Word export using PHPWord
    require __DIR__ . '/../vendor/autoload.php';
    $phpWord = new \PhpOffice\PhpWord\PhpWord();
    $section = $phpWord->addSection();
    $section->addText($content);
    
    $temp_file = tempnam(sys_get_temp_dir(), 'word');
    $objWriter = \PhpOffice\PhpWord\IOFactory::createWriter($phpWord, 'Word2007');
    $objWriter->save($temp_file);
    
    header("Content-Description: File Transfer");
    header('Content-Disposition: attachment; filename="note_'.$noteId.'.docx"');
    header('Content-Type: application/vnd.openxmlformats-officedocument.wordprocessingml.document');
    header('Content-Transfer-Encoding: binary');
    header('Cache-Control: must-revalidate');
    readfile($temp_file);
    unlink($temp_file);
    exit();
} else {
    die("Invalid format requested.");
}
?>
