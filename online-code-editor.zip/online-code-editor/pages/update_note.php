<?php
session_start();
if (!isset($_SESSION['email'])) {
    header("Location: ../email/login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die("Invalid request method.");
}

if (!isset($_POST['id'], $_POST['notesname'], $_POST['submission_date'], $_POST['submission_language'], $_POST['submission_code'], $_POST['submission_output'])) {
    die("Incomplete form submission.");
}

$noteId = intval($_POST['id']);
$notesname = $_POST['notesname'];

// Build the submissions array from the POST data
$submission_dates = $_POST['submission_date'];
$submission_languages = $_POST['submission_language'];
$submission_codes = $_POST['submission_code'];
$submission_outputs = $_POST['submission_output'];

$submissions = [];
$submissionCount = count($submission_dates);
for ($i = 0; $i < $submissionCount; $i++) {
    // Only include if at least one field is non-empty
    if (trim($submission_dates[$i]) != '' || trim($submission_languages[$i]) != '' || trim($submission_codes[$i]) != '' || trim($submission_outputs[$i]) != '') {
        $submissions[] = [
            'date'     => $submission_dates[$i],
            'language' => $submission_languages[$i],
            'code'     => $submission_codes[$i],
            'output'   => $submission_outputs[$i]
        ];
    }
}

// Convert submissions array to JSON
$submissionsJson = json_encode($submissions);

// Update the note in the database
$servername = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "online_editor";

$conn = new mysqli($servername, $dbUsername, $dbPassword, $dbName);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$userEmail = $_SESSION['email'];
$sql = "UPDATE saved_notes SET notesname = ?, submissions = ? WHERE id = ? AND gmail = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssis", $notesname, $submissionsJson, $noteId, $userEmail);
if ($stmt->execute()) {
    // Redirect back with a success flag to trigger the popup message
    header("Location: edit_note.php?id=" . $noteId . "&success=1");
} else {
    echo "Error updating note.";
}
$stmt->close();
$conn->close();
?>
