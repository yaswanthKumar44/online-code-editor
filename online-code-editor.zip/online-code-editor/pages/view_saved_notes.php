<?php
session_start();
if (!isset($_SESSION['email'])) {
    header("Location: ../email/login.php");
    exit();
}

$servername = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "online_editor";

$conn = new mysqli($servername, $dbUsername, $dbPassword, $dbName);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$userEmail = $_SESSION['email'];

// Use a single search input for note name, date, or language
$searchQuery = isset($_GET['query']) ? $_GET['query'] : '';

// Build the SQL query dynamically
$sql = "SELECT * FROM saved_notes WHERE gmail = ?";
if (!empty($searchQuery)) {
    // Search both the notesname field and the submissions JSON text
    $sql .= " AND (notesname LIKE ? OR submissions LIKE ?)";
}

$stmt = $conn->prepare($sql);
$types = "s";
$params = [$userEmail];
if (!empty($searchQuery)) {
    $types .= "ss";
    $params[] = "%" . $searchQuery . "%";
    $params[] = "%" . $searchQuery . "%";
}

$stmt->bind_param($types, ...$params);
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>View Saved Notes</title>
  <!-- SweetAlert2 CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
  <style>
    /* Base styling */
    body {
      margin: 0;
      font-family: Arial, sans-serif;
      background: #f4f4f4;
    }
    .ui-element {
      background: linear-gradient(135deg, 
        #009FE3 0%, 
        #9B00E0 30%, 
        #E80057 60%, 
        #FFD200 100%
      );
      position: relative;
      overflow: hidden;
      padding: 20px;
      min-height: 100vh;
    }
    .ui-element::before,
    .ui-element::after {
      content: "";
      position: absolute;
      background: linear-gradient(to bottom, transparent 40%, rgba(255, 255, 255, 0.5) 60%);
      width: 2px;
      height: 200px;
      transform: rotate(-45deg);
      z-index: 1;
    }
    .ui-element::before {
      left: 20%;
      top: -50px;
    }
    .ui-element::after {
      right: 20%;
      bottom: -50px;
    }
    .ui-element .circle {
      position: absolute;
      border: 2px solid white;
      border-radius: 50%;
      z-index: 1;
    }
    .ui-element .circle:nth-child(1) {
      width: 30px;
      height: 30px;
      left: 10%;
      top: 30%;
    }
    .ui-element .circle:nth-child(2) {
      width: 20px;
      height: 20px;
      right: 30%;
      top: 50%;
    }
    .ui-element .circle:nth-child(3) {
      width: 15px;
      height: 15px;
      left: 40%;
      bottom: 10%;
    }
    .ui-element .dots {
      position: absolute;
      background: radial-gradient(circle, white 2px, transparent 3px);
      background-size: 10px 10px;
      z-index: 1;
    }
    .ui-element .dots:nth-child(4) {
      width: 80px;
      height: 40px;
      left: 5%;
      bottom: 5%;
    }
    .ui-element .dots:nth-child(5) {
      width: 60px;
      height: 30px;
      right: 10%;
      top: 10%;
    }
    .ui-element .stripes {
      position: absolute;
      background: linear-gradient(to bottom, white 1px, transparent 1px);
      background-size: 100% 5px;
      z-index: 1;
    }
    .ui-element .stripes:nth-child(6) {
      width: 100px;
      height: 20px;
      left: 5%;
      top: 10%;
    }
    .ui-element .stripes:nth-child(7) {
      width: 80px;
      height: 15px;
      right: 5%;
      bottom: 15%;
    }
    .notes-container {
      position: relative;
      z-index: 2;
      max-width: 1200px;
      margin: 0 auto;
      background: #fff;
      padding: 20px;
      border-radius: 8px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.2);
    }
    h1 {
      text-align: center;
      color: #333;
    }
    /* Grid for notes: two columns */
    .notes-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
      gap: 20px;
    }
    .note {
      background: #fff;
      border: 1px solid #ddd;
      padding: 15px;
      border-radius: 6px;
      box-shadow: 0 1px 4px rgba(0, 0, 0, 0.1);
      transition: transform 0.2s ease;
      animation: fadeInUp 0.5s ease forwards;
      opacity: 0;
    }
    .note:hover {
      transform: translateY(-5px);
    }
    .note h2 {
      margin-top: 0;
      font-size: 1.2em;
      color: #444;
    }
    .submission {
      margin-top: 10px;
      padding: 10px;
      border-top: 1px dashed #ccc;
    }
    .submission pre {
      background: #f7f7f7;
      padding: 10px;
      border-radius: 4px;
      overflow-x: auto;
    }
    .btn {
      padding: 8px 12px;
      background-color: #007BFF;
      color: #fff;
      text-decoration: none;
      border: none;
      border-radius: 4px;
      margin-right: 5px;
      cursor: pointer;
    }
    .btn:hover {
      background-color: #0056b3;
    }
    .btn-danger {
      background-color: #DC3545;
    }
    .btn-danger:hover {
      background-color: #a71d2a;
    }
    .btn.highlight {
      background-color: #28a745;
      border: 2px solid #1e7e34;
      font-weight: bold;
    }
    .search-form {
      margin-bottom: 20px;
      text-align: center;
    }
    .search-form input[type="text"] {
      padding: 6px;
      margin-right: 5px;
      border: 1px solid #ccc;
      border-radius: 4px;
      width: 60%;
    }
    .search-form button {
      padding: 6px 12px;
      border: none;
      border-radius: 4px;
      background-color: #007BFF;
      color: #fff;
      cursor: pointer;
    }
    .search-form button:hover {
      background-color: #0056b3;
    }
  /* Fade-in animation keyframes */
    @keyframes fadeInUp {
      from {
        opacity: 0;
        transform: translateY(20px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }
  </style>
</head>
<body>
<div class="ui-element">
  <!-- Decorative elements -->
  <div class="circle"></div>
  <div class="circle"></div>
  <div class="circle"></div>
  <div class="dots"></div>
  <div class="dots"></div>
  <div class="stripes"></div>
  <div class="stripes"></div>
  
  <div class="notes-container">
    <h1>Saved Notes for <?php echo htmlspecialchars($userEmail); ?></h1>
    
    <!-- Single Search Form -->
    <form method="GET" action="" class="search-form">
      <input type="text" name="query" placeholder="Search by note name, date, or language" value="<?php echo htmlspecialchars($searchQuery); ?>">
      <button type="submit" class="btn">Search</button>
    </form>
    
    <!-- Highlighted Dashboard Button -->
    <div style="text-align:center; margin-bottom:20px;">
      <a href="dashboard.php" class="btn highlight">Go to Dashboard</a>
    </div>
    
    <!-- Option to Download All Notes -->
    <div style="text-align:center; margin-bottom:20px;">
      <a href="download_all.php?format=pdf" class="btn download-link">Download All as PDF</a>
    </div>
    
    <?php if($result->num_rows == 0): ?>
      <p style="text-align:center;">No saved notes found.</p>
    <?php else: ?>
      <div class="notes-grid">
        <?php while($row = $result->fetch_assoc()): ?>
          <div class="note">
            <h2>Note: <?php echo htmlspecialchars($row['notesname']); ?></h2>
            
            <!-- Display submissions -->
            <?php
              $submissions = json_decode($row['submissions'], true);
              if (!is_array($submissions) || empty($submissions)) {
                  echo "<p>No submissions found for this note.</p>";
              } else {
                  foreach ($submissions as $submission) {
                      echo '<div class="submission">';
                      echo '<p><strong>Date:</strong> ' . htmlspecialchars($submission['date']) . '</p>';
                      echo '<p><strong>Language:</strong> ' . htmlspecialchars($submission['language']) . '</p>';
                      echo '<p><strong>Code:</strong></p><pre>' . htmlspecialchars($submission['code']) . '</pre>';
                      echo '<p><strong>Output:</strong></p><pre>' . htmlspecialchars($submission['output']) . '</pre>';
                      echo '</div>';
                  }
              }
            ?>
            
            <!-- Action Buttons -->
            <div style="margin-top:10px;">
              <a href="edit_note.php?id=<?php echo $row['id']; ?>" class="btn">Edit</a>
              <form class="deleteForm" action="delete_note.php" method="POST" style="display:inline;">
                <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                <button type="submit" class="btn btn-danger">Delete</button>
              </form>
              <!-- Individual PDF Download Link with animation -->
              <a href="download.php?id=<?php echo $row['id']; ?>&format=pdf" class="btn download-link">Download PDF</a>
            </div>
          </div>
        <?php endwhile; ?>
      </div>
    <?php endif; ?>
  </div>
</div>

<!-- Include SweetAlert2 from CDN -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
  // Delete confirmation functionality
  document.querySelectorAll('.deleteForm').forEach(function(form) {
      form.addEventListener('submit', function(e) {
          e.preventDefault();
          Swal.fire({
              title: 'Are you sure?',
              text: "Do you want to delete this note?",
              icon: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#DC3545',
              cancelButtonColor: '#6c757d',
              confirmButtonText: 'Yes, delete it!'
          }).then((result) => {
              if (result.isConfirmed) {
                  form.submit();
              }
          });
      });
  });

  // Display deletion success message if delete parameter is set
  <?php if(isset($_GET['delete']) && $_GET['delete'] == 'success'): ?>
    Swal.fire({
        icon: 'success',
        title: 'Deleted!',
        text: 'Your note has been deleted successfully.',
        timer: 2000,
        showConfirmButton: false
    });
  <?php endif; ?>

  // Download animation for PDF download links
  document.querySelectorAll('.download-link').forEach(function(link) {
      link.addEventListener('click', function(e) {
          e.preventDefault();
          Swal.fire({
              title: 'Preparing your download...',
              html: 'Please wait while your PDF is being generated.',
              didOpen: () => {
                  Swal.showLoading();
              },
              allowOutsideClick: false
          });
          setTimeout(function() {
              window.location.href = link.href;
              Swal.fire({
                  icon: 'success',
                  title: 'Download started!',
                  showConfirmButton: false,
                  timer: 1500
              });
          }, 2000);
      });
  });
</script>
<?php
$stmt->close();
$conn->close();
?>
</body>
</html>
