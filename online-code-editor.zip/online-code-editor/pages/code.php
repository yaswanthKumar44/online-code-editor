<?php
// public/index.php - Main landing page with language icons and simplified gradient design
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Online Code Editor - Home</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- Optional: SweetAlert2 CSS for future popups -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
  <style>
    /* Global Reset */
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    /* Body Styling with a clean gradient background */
    body {
      font-family: Arial, sans-serif;
      background: linear-gradient(135deg, #4B0082, #87CEEB);
      min-height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      color: #fff;
    }

    /* Container for the dashboard content */
    .dashboard-container {
      background: rgba(0, 0, 0, 0.6);
      border-radius: 10px;
      padding: 40px;
      width: 90%;
      max-width: 900px;
      text-align: center;
      animation: fadeIn 1s ease;
    }

    /* Simple fade-in animation */
    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(-20px); }
      to { opacity: 1; transform: translateY(0); }
    }

    /* Heading style */
    .dashboard-container h2 {
      margin-bottom: 20px;
    }

    /* Grid for language icons/options */
    .dashboard-options {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
      gap: 20px;
      margin-top: 20px;
    }

    /* Styling for each language option */
    .option {
      background: rgba(255, 255, 255, 0.1);
      padding: 20px;
      border-radius: 8px;
      transition: background 0.3s ease, transform 0.3s ease;
      text-decoration: none;
      color: inherit;
    }
    .option:hover {
      background: rgba(255, 255, 255, 0.2);
      transform: translateY(-5px);
    }
    .option img {
      width: 64px;
      height: 64px;
      margin-bottom: 10px;
    }

    /* Simple button style */
    .button {
      display: inline-block;
      padding: 10px 20px;
      margin-bottom: 20px;
      background: transparent;
      border: 2px solid #fff;
      border-radius: 5px;
      text-decoration: none;
      color: #fff;
      transition: background 0.3s ease;
    }
    .button:hover {
      background: rgba(255, 255, 255, 0.2);
    }

    /* Footer styling */
    footer {
      position: fixed;
      bottom: 0;
      width: 100%;
      text-align: center;
      padding: 10px;
      background: rgba(0, 0, 0, 0.4);
      color: #fff;
    }
  </style>
</head>
<body>
  <div class="dashboard-container">
    <a href="dashboard.php" class="button">Go to Dashboard</a>
    <h2>Welcome to the Online Code Editor</h2>
    <div class="dashboard-options">
      <a href="../editors/c_editor.php" class="option">
        <img src="../assets/img/language_icons/c.png" alt="C">
        <p>C</p>
      </a>
      <a href="../editors/cpp_editor.php" class="option">
        <img src="../assets/img/language_icons/cpp.png" alt="C++">
        <p>C++</p>
      </a>
      <a href="../editors/csharp_editor.php" class="option">
        <img src="../assets/img/language_icons/csharp.png" alt="C#">
        <p>C#</p>
      </a>
      <a href="../editors/java_editor.php" class="option">
        <img src="../assets/img/language_icons/java.png" alt="Java">
        <p>Java</p>
      </a>
      <a href="../editors/python_editor.php" class="option">
        <img src="../assets/img/language_icons/python.png" alt="Python">
        <p>Python</p>
      </a>
      <a href="../editors/php_editor.php" class="option">
        <img src="../assets/img/language_icons/php.png" alt="PHP">
        <p>PHP</p>
      </a>
      <a href="../editors/r_editor.php" class="option">
        <img src="../assets/img/language_icons/r.png" alt="R">
        <p>R</p>
      </a>
      <a href="../editors/html_editor.php" class="option">
        <img src="../assets/img/language_icons/html.png" alt="HTML, CSS, JS">
        <p>HTML, CSS, JS</p>
      </a>
      
    </div>
  </div>
  <footer>
    <p>© <?php echo date("Y"); ?> Online Code Editor</p>
  </footer>
</body>
</html>
