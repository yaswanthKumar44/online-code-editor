<?php
session_start();
if (!isset($_SESSION['email'])) {
    header("Location: ../email/login.php");
    exit();
}

if (!isset($_GET['format'])) {
    die("Format not specified.");
}

$format = $_GET['format']; // Expected: pdf or word

$servername = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "online_editor";

$conn = new mysqli($servername, $dbUsername, $dbPassword, $dbName);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$userEmail = $_SESSION['email'];
$sql = "SELECT * FROM saved_notes WHERE gmail = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $userEmail);
$stmt->execute();
$result = $stmt->get_result();

$content = "All Saved Notes for " . $userEmail . "\n\n";
if ($result->num_rows == 0) {
    $content .= "No saved notes found.";
} else {
    while ($note = $result->fetch_assoc()) {
        $content .= "Note: " . $note['notesname'] . "\n";
        $submissions = json_decode($note['submissions'], true);
        if (is_array($submissions)) {
            foreach ($submissions as $submission) {
                $content .= "  Date: " . $submission['date'] . "\n";
                $content .= "  Language: " . $submission['language'] . "\n";
                $content .= "  Code:\n" . $submission['code'] . "\n";
                $content .= "  Output:\n" . $submission['output'] . "\n";
                $content .= "  -------------------------\n";
            }
        } else {
            $content .= "  No submissions found.\n";
        }
        $content .= "\n============================\n\n";
    }
}
$stmt->close();
$conn->close();

if ($format === "pdf") {
    // PDF export using FPDF
    require('../fpdf/fpdf.php');
    $pdf = new FPDF();
    $pdf->AddPage();
    $pdf->SetFont('Arial','',12);
    $pdf->MultiCell(0,10, $content);
    
    header('Content-Type: application/pdf');
    header('Content-Disposition: attachment; filename="all_notes.pdf"');
    $pdf->Output('D', "all_notes.pdf");
    exit();
} elseif ($format === "word") {
    // Word export using PHPWord
    require 'vendor/autoload.php';
    $phpWord = new \PhpOffice\PhpWord\PhpWord();
    $section = $phpWord->addSection();
    $section->addText($content);
    
    $temp_file = tempnam(sys_get_temp_dir(), 'word');
    $objWriter = \PhpOffice\PhpWord\IOFactory::createWriter($phpWord, 'Word2007');
    $objWriter->save($temp_file);
    
    header("Content-Description: File Transfer");
    header('Content-Disposition: attachment; filename="all_notes.docx"');
    header('Content-Type: application/vnd.openxmlformats-officedocument.wordprocessingml.document');
    header('Content-Transfer-Encoding: binary');
    header('Cache-Control: must-revalidate');
    readfile($temp_file);
    unlink($temp_file);
    exit();
} else {
    die("Invalid format requested.");
}
?>
