<?php
session_start();
if (!isset($_SESSION['email'])) {
    header("Location: ../email/login.php");
    exit();
}

if (!isset($_GET['id'])) {
    die("Note ID not specified.");
}

$noteId = intval($_GET['id']);

$servername = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "online_editor";

$conn = new mysqli($servername, $dbUsername, $dbPassword, $dbName);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$userEmail = $_SESSION['email'];
$sql = "SELECT * FROM saved_notes WHERE id = ? AND gmail = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("is", $noteId, $userEmail);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows == 0) {
    die("Note not found or access denied.");
}
$note = $result->fetch_assoc();
$stmt->close();
$conn->close();

// Decode submissions JSON (if any)
$submissions = json_decode($note['submissions'], true);
if (!is_array($submissions)) {
    $submissions = []; // start with an empty array if no submissions exist
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Edit Note</title>
  <!-- SweetAlert2 CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
  <style>
    /* Dark Theme Styles */
    body {
      font-family: Arial, sans-serif;
      margin: 20px;
      background-color: #000000;
      color: #00ff00;
      transition: background-color 0.3s, color 0.3s;
    }
    .container {
      max-width: 800px;
      margin: auto;
    }
    input[type="text"],
    input[type="date"],
    textarea {
      width: 100%;
      padding: 8px;
      margin: 4px 0 10px 0;
      box-sizing: border-box;
      background-color: #333;
      color: #00ff00;
      border: 1px solid #00ff00;
    }
    label {
      font-weight: bold;
    }
    .submission-block {
      border: 1px solid #00ff00;
      padding: 10px;
      margin-bottom: 15px;
      transition: opacity 0.5s ease-out;
    }
    .btn {
      padding: 8px 12px;
      background-color: #007BFF;
      color: white;
      border: none;
      cursor: pointer;
      border-radius: 4px;
      margin-right: 5px;
    }
    .btn:hover {
      background-color: #0056b3;
    }
    .btn-success {
      background-color: #28a745;
    }
    .btn-success:hover {
      background-color: #218838;
    }
    .btn-danger {
      background-color: #DC3545;
    }
    .btn-danger:hover {
      background-color: #a71d2a;
    }
    /* Navigation Bar */
    nav.navbar {
      background-color: #111;
      padding: 10px;
      display: flex;
      justify-content: center;
      gap: 20px;
      margin-bottom: 20px;
    }
    .nav-link {
      text-decoration: none;
      color: #00ff00;
      font-weight: bold;
      padding: 5px 10px;
      border: 1px solid transparent;
      cursor: pointer;
    }
    .nav-link:hover {
      border: 1px solid #00ff00;
    }
    /* Option styling for view notes link */
    .option {
      padding: 5px 10px;
      background-color: #28a745;
      border-radius: 4px;
      color: white;
    }
  </style>
</head>
<body>
<!-- Top Navigation Bar -->
<nav class="navbar">
  <a href="dashboard.php" class="nav-link">Dashboard</a>
  <a href="view_saved_notes.php" class="nav-link"><div class="option">Notes 📝</div></a>
</nav>

<div class="container">
  <h1>Edit Note: <?php echo htmlspecialchars($note['notesname']); ?></h1>
  
  <!-- Success popup (if redirected with success=1) -->
  <?php if(isset($_GET['success']) && $_GET['success'] == 1): ?>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
      Swal.fire({
        icon: 'success',
        title: 'Success!',
        text: 'Note updated successfully!',
        timer: 2000,
        showConfirmButton: false,
        animation: true
      });
    </script>
  <?php endif; ?>
  
  <form action="update_note.php" method="POST">
    <input type="hidden" name="id" value="<?php echo $note['id']; ?>">
    
    <label for="notesname">Note Name:</label>
    <input type="text" id="notesname" name="notesname" value="<?php echo htmlspecialchars($note['notesname']); ?>" required>
    
    <h2>Submissions</h2>
    <div id="submissions-container">
      <?php foreach ($submissions as $index => $submission): ?>
      <div class="submission-block">
        <label>Date:</label>
        <input type="date" name="submission_date[]" value="<?php echo htmlspecialchars(date('Y-m-d', strtotime($submission['date']))); ?>" required>
        
        <label>Language:</label>
        <input type="text" name="submission_language[]" value="<?php echo htmlspecialchars($submission['language']); ?>" required>
        
        <label>Code:</label>
        <textarea name="submission_code[]" rows="4" required><?php echo htmlspecialchars($submission['code']); ?></textarea>
        
        <label>Output:</label>
        <textarea name="submission_output[]" rows="4" required><?php echo htmlspecialchars($submission['output']); ?></textarea>
        
        <button type="button" class="btn btn-danger" onclick="removeSubmission(this)">Remove Submission</button>
      </div>
      <?php endforeach; ?>
    </div>
    
    <button type="button" class="btn" onclick="addSubmission()">Add Submission</button>
    <br><br>
    <button type="submit" class="btn btn-success">Update Note</button>
  </form>
  
  <!-- Hidden template for new submission -->
  <div id="submission-template" style="display:none;">
    <div class="submission-block">
      <label>Date:</label>
      <input type="date" name="submission_date[]" required>
      
      <label>Language:</label>
      <input type="text" name="submission_language[]" required>
      
      <label>Code:</label>
      <textarea name="submission_code[]" rows="4" required></textarea>
      
      <label>Output:</label>
      <textarea name="submission_output[]" rows="4" required></textarea>
      
      <button type="button" class="btn btn-danger" onclick="removeSubmission(this)">Remove Submission</button>
    </div>
  </div>
</div>

<!-- Include SweetAlert2 from CDN -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
  function addSubmission(){
      var template = document.getElementById('submission-template').innerHTML;
      var container = document.getElementById('submissions-container');
      container.insertAdjacentHTML('beforeend', template);
  }
  
  function removeSubmission(button) {
      var container = document.getElementById('submissions-container');
      var submissionBlocks = container.querySelectorAll('.submission-block');
      
      // Prevent deletion if only one submission block remains
      if (submissionBlocks.length <= 1) {
          Swal.fire({
             icon: 'error',
             title: 'Error!',
             text: 'At least one submission is required.',
             timer: 1500,
             toast: true,
             position: 'top-end',
             showConfirmButton: false,
             animation: true
          });
          return;
      }
      
      // Remove the specific submission block using closest() method
      var submissionBlock = button.closest('.submission-block');
      submissionBlock.style.opacity = 0;
      
      setTimeout(function() {
          submissionBlock.remove();
          Swal.fire({
             icon: 'success',
             title: 'Removed!',
             text: 'Submission removed successfully!',
             timer: 1500,
             toast: true,
             position: 'top-end',
             showConfirmButton: false,
             animation: true
          });
      }, 500);
  }
</script>
</body>
</html>
