-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 26, 2025 at 05:02 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `online_editor`
--

-- --------------------------------------------------------

--
-- Table structure for table `saved_notes`
--

CREATE TABLE `saved_notes` (
  `id` int(11) NOT NULL,
  `gmail` varchar(255) NOT NULL,
  `notesname` varchar(255) NOT NULL,
  `submissions` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `saved_notes`
--

INSERT INTO `saved_notes` (`id`, `gmail`, `notesname`, `submissions`) VALUES
(6, 'yashyaswanth714@gmail.com', 'yug', '[{\"date\":\"2025-03-02\",\"language\":\"C++\",\"code\":\"#include <iostream>\\r\\n\\r\\nint main() {\\r\\n    \\/\\/ Using auto for type inference (C++11 feature)\\r\\n    auto num1 = 10;\\r\\n    auto num2 = 20;\\r\\n\\r\\n    \\/\\/ Using a lambda expression (C++11 feature) for addition\\r\\n    auto sum =(int a, int b) { return a + b; }; \\/\\/ Corrected line\\r\\n\\r\\n    \\/\\/ Calculating the sum\\r\\n    auto result = sum(num1, num2);\\r\\n\\r\\n    \\/\\/ Using range-based for loop (C++11 feature) to print a message\\r\\n    std::cout << \\\"The sum of \\\" << num1 << \\\" and \\\" << num2 << \\\" is: \\\" << result << std::endl;\\r\\n\\r\\n    return 0;\\r\\n}\",\"output\":\"main.cpp: In function \'int main()\':\\r\\nmain.cpp:9:16: error: expected primary-expression before \'int\'\\r\\n     auto sum =(int a, int b) { return a + b; }; \\/\\/ Corrected line\\r\\n                ^~~\\r\\nmain.cpp:9:16: error: expected \')\' before \'int\'<br \\/>\\r\\n<b>Warning<\\/b>:  unlink(a.exe): No such file or directory in <b>C:\\\\xampp\\\\htdocs\\\\online-code-editor\\\\editors\\\\cpp_compiler.php<\\/b> on line <b>51<\\/b><br \\/>\"}]'),
(11, 'yashyaswanth714@gmail.com', 's', '[{\"code\":\"using System;\\n\\npublic class Program\\n{\\n    public static void Main(stringargs)\\n    {\\n        Console.WriteLine(\\\"Enter the first number:\\\");\\n        int num1 = int.Parse(Console.ReadLine());\\n\\n        Console.WriteLine(\\\"Enter the second number:\\\");\\n        int num2 = int.Parse(Console.ReadLine());\\n\\n        int sum = num1 + num2;\\n\\n        Console.WriteLine($\\\"The sum of {num1} and {num2} is: {sum}\\\");\\n    }\\n}\",\"language\":\"C#\",\"output\":\"Compilation Error: <br>main.cs(5,38): error CS1001: Unexpected symbol `)\', expecting identifier\",\"date\":\"2025-03-02 20:28:11\"}]'),
(12, 'yashyaswanth714@gmail.com', 'he', '[{\"date\":\"2025-03-02\",\"language\":\"PHP\",\"code\":\"<?php\\r\\necho \'Hello World!\';\\r\\n?>\",\"output\":\"Hello World!\"}]'),
(14, 'yashyaswanth714@gmail.com', 'c', '[{\"code\":\"#include <stdio.h>\\n\\nint main() {\\n    int num1, num2, sum;\\n\\n    num1 = 5;\\n    num2 = 10;\\n    sum = num1 + num2;\\n\\n    printf(\\\"Sum: %d\\\\n\\\", sum);\\n\\n    return 0;\\n}\",\"language\":\"C\",\"output\":\"Sum: 15\",\"date\":\"2025-03-04 19:18:01\"}]'),
(15, 'yashyaswanth714@gmail.com', 'c++', '[{\"date\":\"2025-03-04\",\"language\":\"C++11\",\"code\":\"#include <iostream>\\r\\n\\r\\nint main() {\\r\\n    int num1 = 5;\\r\\n    int num2 = 10;\\r\\n    int sum = num1 + num2;\\r\\n\\r\\n    std::cout << \\\"Sum: \\\" << sum << std::endl;\\r\\n\\r\\n    return 0;\\r\\n}\",\"output\":\"Sum: 15\"}]'),
(16, 'yashyaswanth714@gmail.com', 'java', '[{\"date\":\"2025-03-05\",\"language\":\"Java\",\"code\":\"\\/\\/ Java (Input from console, no print prompts)\\r\\nimport java.util.Scanner;\\r\\n\\r\\npublic class Main {\\r\\n    public static void main(String[] args) {\\r\\n        Scanner input = new Scanner(System.in);\\r\\n        int num1 = input.nextInt();\\r\\n        int num2 = input.nextInt();\\r\\n        int sum = num1 + num2;\\r\\n        System.out.println(sum);\\r\\n        input.close();\\r\\n    }\\r\\n}\",\"output\":\"10\"}]'),
(17, 'yashyaswanth714@gmail.com', 'python', '[{\"code\":\"num1 = 5\\nnum2 = 10\\nsum = num1 + num2\\nprint(\\\"Sum:\\\", sum)\",\"language\":\"Python\",\"output\":\"Sum: 15\",\"date\":\"2025-03-04 19:19:30\"}]'),
(18, 'yashyaswanth714@gmail.com', 'c#', '[{\"code\":\"using System;\\n\\npublic class Sum\\n{\\n    public static void Main(string[] args)\\n    {\\n        int num1 = 5;\\n        int num2 = 10;\\n        int sum = num1 + num2;\\n\\n        Console.WriteLine(\\\"Sum: \\\" + sum);\\n    }\\n}\",\"language\":\"C#\",\"output\":\"Sum: 15\",\"date\":\"2025-03-04 19:20:04\"}]'),
(19, 'yashyaswanth714@gmail.com', 'php', '[{\"code\":\"<?php\\n$num1 = 5;\\n$num2 = 10;\\n$sum = $num1 + $num2;\\n\\necho \\\"Sum: \\\" . $sum;\\n?>\",\"language\":\"PHP\",\"output\":\"Sum: 15\",\"date\":\"2025-03-04 19:20:27\"}]'),
(20, 'yashyaswanth714@gmail.com', 'js', '[{\"code\":\"let num1 = 5;\\nlet num2 = 10;\\nlet sum = num1 + num2;\\n\\nconsole.log(\\\"Sum: \\\" + sum);\",\"language\":\"JavaScript\",\"output\":\"Sum: 15\",\"date\":\"2025-03-04 19:20:54\"}]'),
(21, 'yashyaswanth714@gmail.com', 'r', '[{\"code\":\"# R - Basic addition\\nnum1 <- 5\\nnum2 <- 10\\nsum <- num1 + num2\\nprint(paste(\\\"Sum (basic):\\\", sum))\\n\\n# R - Function\\nadd_numbers <- function(x, y) {\\n  return(x + y)\\n}\\n\\nresult1 <- add_numbers(5, 10)\\nprint(paste(\\\"Sum (function):\\\", result1))\\n\\n# R - User input from console\\n# num3 <- as.numeric(readline(prompt = \\\"Enter first number: \\\"))\\n# num4 <- as.numeric(readline(prompt = \\\"Enter second number: \\\"))\\n#\\n# if (!is.na(num3) && !is.na(num4)) {\\n#   result2 <- num3 + num4\\n#   print(paste(\\\"Sum (user input):\\\", result2))\\n# } else {\\n#   print(\\\"Invalid input. Please enter numbers.\\\")\\n# }\\n\\n#R - vectorized addition\\nnumbers1 <- c(1,2,3,4,5)\\nnumbers2 <- c(6,7,8,9,10)\\nsum_vector <- numbers1 + numbers2\\nprint(paste(\\\"Vector Sum:\\\", sum_vector))\",\"language\":\"R\",\"output\":\"[1] \\\"Sum (basic): 15\\\"\\n[1] \\\"Sum (function): 15\\\"\\n[1] \\\"Vector Sum: 7\\\"  \\\"Vector Sum: 9\\\"  \\\"Vector Sum: 11\\\" \\\"Vector Sum: 13\\\"\\n[5] \\\"Vector Sum: 15\\\"\",\"date\":\"2025-03-04 19:21:56\"}]'),
(22, 'yashyaswanth714@gmail.com', 'html', '[{\"code\":\"<!DOCTYPE html>\\n<html>\\n<head>\\n    <title>Simple Calculator<\\/title>\\n    <link rel=\\\"stylesheet\\\" href=\\\"style.css\\\">\\n<\\/head>\\n<body>\\n    <div class=\\\"calculator\\\">\\n        <input type=\\\"text\\\" id=\\\"result\\\" readonly>\\n        <br>\\n        <button onclick=\\\"appendToResult(\'7\')\\\">7<\\/button>\\n        <button onclick=\\\"appendToResult(\'8\')\\\">8<\\/button>\\n        <button onclick=\\\"appendToResult(\'9\')\\\">9<\\/button>\\n        <button onclick=\\\"appendToResult(\'+\')\\\" class=\\\"operator\\\">+<\\/button>\\n        <br>\\n        <button onclick=\\\"appendToResult(\'4\')\\\">4<\\/button>\\n        <button onclick=\\\"appendToResult(\'5\')\\\">5<\\/button>\\n        <button onclick=\\\"appendToResult(\'6\')\\\">6<\\/button>\\n        <button onclick=\\\"appendToResult(\'-\')\\\" class=\\\"operator\\\">-<\\/button>\\n        <br>\\n        <button onclick=\\\"appendToResult(\'1\')\\\">1<\\/button>\\n        <button onclick=\\\"appendToResult(\'2\')\\\">2<\\/button>\\n        <button onclick=\\\"appendToResult(\'3\')\\\">3<\\/button>\\n        <button onclick=\\\"appendToResult(\'*\')\\\" class=\\\"operator\\\">*<\\/button>\\n        <br>\\n        <button onclick=\\\"appendToResult(\'0\')\\\">0<\\/button>\\n        <button onclick=\\\"appendToResult(\'.\')\\\">.<\\/button>\\n        <button onclick=\\\"calculate()\\\" class=\\\"equals\\\">=<\\/button>\\n        <button onclick=\\\"appendToResult(\'\\/\')\\\" class=\\\"operator\\\">\\/<\\/button>\\n        <br>\\n        <button onclick=\\\"clearResult()\\\">C<\\/button>\\n    <\\/div>\\n    <script src=\\\"script.js\\\"><\\/script>\\n<\\/body>\\n<\\/html>\\n\\/* CSS (style.css) *\\/\\n.calculator {\\n    width: 300px;\\n    margin: 50px auto;\\n    border: 1px solid #ccc;\\n    padding: 20px;\\n    border-radius: 5px;\\n    background-color: #f0f0f0;\\n}\\n\\n.calculator input[type=\\\"text\\\"] {\\n    width: 95%;\\n    margin-bottom: 10px;\\n    padding: 10px;\\n    font-size: 18px;\\n    border: 1px solid #ddd;\\n    border-radius: 3px;\\n}\\n\\n.calculator button {\\n    width: 60px;\\n    height: 40px;\\n    margin: 5px;\\n    font-size: 16px;\\n    border: 1px solid #bbb;\\n    border-radius: 3px;\\n    background-color: #eee;\\n    cursor: pointer;\\n}\\n\\n.calculator button.operator {\\n    background-color: #ddd;\\n}\\n\\n.calculator button.equals {\\n    background-color: #007bff;\\n    color: white;\\n}\\n\\/* JavaScript (script.js) *\\/\\nfunction appendToResult(value) {\\n    document.getElementById(\\\"result\\\").value += value;\\n}\\n\\nfunction clearResult() {\\n    document.getElementById(\\\"result\\\").value = \\\"\\\";\\n}\\n\\nfunction calculate() {\\n    try {\\n        document.getElementById(\\\"result\\\").value = eval(document.getElementById(\\\"result\\\").value);\\n    } catch (error) {\\n        document.getElementById(\\\"result\\\").value = \\\"Error\\\";\\n    }\\n}\",\"language\":\"HTML\\/CSS\\/JS\",\"output\":\"7\\n        8\\n        9\\n        +\\n        \\n        4\\n        5\\n        6\\n        -\\n        \\n        1\\n        2\\n        3\\n        *\\n        \\n        0\\n        .\\n        =\\n        \\/\\n        \\n        C\\n    \\n    \\n\\n\\n\\n\\/* CSS (style.css) *\\/\\n.calculator {\\n    width: 300px;\\n    margin: 50px auto;\\n    border: 1px solid #ccc;\\n    padding: 20px;\\n    border-radius: 5px;\\n    background-color: #f0f0f0;\\n}\\n\\n.calculator input[type=\\\"text\\\"] {\\n    width: 95%;\\n    margin-bottom: 10px;\\n    padding: 10px;\\n    font-size: 18px;\\n    border: 1px solid #ddd;\\n    border-radius: 3px;\\n}\\n\\n.calculator button {\\n    width: 60px;\\n    height: 40px;\\n    margin: 5px;\\n    font-size: 16px;\\n    border: 1px solid #bbb;\\n    border-radius: 3px;\\n    background-color: #eee;\\n    cursor: pointer;\\n}\\n\\n.calculator button.operator {\\n    background-color: #ddd;\\n}\\n\\n.calculator button.equals {\\n    background-color: #007bff;\\n    color: white;\\n}\\n\\n\\n\\/* JavaScript (script.js) *\\/\\nfunction appendToResult(value) {\\n    document.getElementById(\\\"result\\\").value += value;\\n}\\n\\nfunction clearResult() {\\n    document.getElementById(\\\"result\\\").value = \\\"\\\";\\n}\\n\\nfunction calculate() {\\n    try {\\n        document.getElementById(\\\"result\\\").value = eval(document.getElementById(\\\"result\\\").value);\\n    } catch (error) {\\n        document.getElementById(\\\"result\\\").value = \\\"Error\\\";\\n    }\\n}\",\"date\":\"2025-03-04 19:23:20\"}]');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `registration_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `profile_photo` varchar(255) DEFAULT NULL,
  `gender` enum('Male','Female','Other') DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `phone_number` varchar(15) DEFAULT NULL,
  `role` enum('Student','Faculty','Other') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `registration_date`, `profile_photo`, `gender`, `dob`, `phone_number`, `role`) VALUES
(4, 'yaswanth kumar', 'yashyaswanth714@gmail.com', '$2y$10$xG5uN4lv6odCYgM0Tt8b5OetLJI2tEbUhaVbY3cgQ5.oE7UTxVXXi', '2025-03-05 18:24:23', 'uploads/67c8976d662a8.png', 'Male', '2005-06-04', '2987348923', 'Other'),
(5, 'yash', 'pyaswanth455664@gmail.com', '$2y$10$0wo9UxWDDlgsv4PCOSjyM.1MCxt3Z7C6bifMj/SAtp1QSnr0.o3JK', '2025-03-10 07:02:03', NULL, NULL, NULL, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `saved_notes`
--
ALTER TABLE `saved_notes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_note` (`gmail`,`notesname`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `saved_notes`
--
ALTER TABLE `saved_notes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
