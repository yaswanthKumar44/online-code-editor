 
CREATE DATABASE IF NOT EXISTS online_editor;
USE online_editor;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
ALTER TABLE users
ADD COLUMN profile_photo VARCHAR(255),
ADD COLUMN gender ENUM('Male', 'Female', 'Other'),
ADD COLUMN dob DATE,
ADD COLUMN phone_number VARCHAR(15),
ADD COLUMN role ENUM('Student', 'Faculty', 'Other');

CREATE TABLE saved_notes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    gmail VARCHAR(255) NOT NULL,
    notesname VARCHAR(255) NOT NULL,
    submissions TEXT NOT NULL, -- JSON-encoded array of submissions
    UNIQUE KEY unique_note (gmail, notesname)
);
