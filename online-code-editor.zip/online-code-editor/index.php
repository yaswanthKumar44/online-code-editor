<?php
// public/index.php - Professional Landing Page with Enhanced Hover Effects
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Online Code Editor - Home</title>
  <!-- Include SweetAlert2 CSS & JS if needed -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <style>
    /* Reset & Base Styles */
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    body {
      font-family: 'Segoe UI', sans-serif;
      line-height: 1.6;
      color: #333;
      background: linear-gradient(135deg, #e0eafc, #cfdef3);
      scroll-behavior: smooth;
    }
    a {
      text-decoration: none;
      color: inherit;
    }
    
    /* Header with Authentication and Navigation */
    header {
      background: #003399;
      color: #fff;
      padding: 20px;
      display: flex;
      flex-direction: column;
      align-items: center;
      position: sticky;
      top: 0;
      z-index: 100;
      box-shadow: 0 2px 8px rgba(0,0,0,0.2);
      transition: background 0.3s ease;
    }
    /* Authentication Buttons (Top Right) */
    .auth-buttons {
      align-self: flex-end;
      margin-bottom: 10px;
    }
    .auth-buttons a {
      margin: 0 5px;
      padding: 8px 16px;
      background: #fff;
      color: #003399;
      border-radius: 50px;
      font-weight: bold;
      transition: transform 0.3s ease, box-shadow 0.3s ease;
    }
    .auth-buttons a:hover {
      transform: scale(1.05);
      box-shadow: 0 4px 12px rgba(0,0,0,0.3);
    }
    header h1 {
      font-size: 2.5rem;
      margin-bottom: 10px;
    }
    nav {
      margin-top: 10px;
    }
    nav ul {
      list-style: none;
      display: flex;
      gap: 20px;
    }
    nav ul li a {
      padding: 10px 20px;
      background: #fff;
      color: #003399;
      border-radius: 50px;
      font-weight: bold;
      transition: background 0.3s, transform 0.3s;
    }
    nav ul li a:hover {
      background: #f0f0f0;
      transform: scale(1.05);
    }
    
    /* Main Content */
    main {
      max-width: 1200px;
      margin: 40px auto;
      padding: 20px;
    }
    section {
      padding: 60px 20px;
      border-bottom: 1px solid #ddd;
      background: rgba(255, 255, 255, 0.8);
      border-radius: 10px;
      margin-bottom: 30px;
      transition: transform 0.3s, box-shadow 0.3s;
      opacity: 0;
      transform: translateY(20px);
      animation: fadeIn 1s forwards;
    }
    section:hover {
      transform: translateY(-5px);
      box-shadow: 0 8px 16px rgba(0,0,0,0.2);
    }
    section:nth-of-type(1) { animation-delay: 0.2s; }
    section:nth-of-type(2) { animation-delay: 0.4s; }
    section:nth-of-type(3) { animation-delay: 0.6s; }
    section:nth-of-type(4) { animation-delay: 0.8s; }
    section h2 {
      font-size: 2rem;
      margin-bottom: 20px;
      color: #003399;
    }
    section p {
      margin-bottom: 20px;
    }
    
    /* Language Icons Section */
    #language-icons {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      gap: 20px;
      margin-top: 30px;
    }
    #language-icons a {
      width: 100px;
      text-align: center;
      transition: transform 0.3s, filter 0.3s;
    }
    #language-icons a:hover {
      transform: scale(1.1);
      filter: brightness(1.2);
    }
    #language-icons img {
      width: 64px;
      height: 64px;
      display: block;
      margin: 0 auto 10px;
    }
    
    /* Developers Section */
    #developers {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      gap: 30px;
    }
    #developers .dev-card {
      background: #fff;
      border: 1px solid #ddd;
      border-radius: 10px;
      padding: 20px;
      text-align: center;
      width: 200px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
      transition: transform 0.3s;
    }
    #developers .dev-card:hover {
      transform: scale(1.05);
    }
    #developers .dev-card img {
      width: 100px;
      height: 100px;
      border-radius: 50%;
      margin-bottom: 10px;
    }
    #developers .dev-card h3 {
      margin-bottom: 5px;
      font-size: 1.2rem;
      color: #003399;
    }
    #developers .dev-card p {
      font-size: 0.9rem;
      color: #666;
    }
    
    /* Footer */
    footer {
      background: #003399;
      color: #fff;
      text-align: center;
      padding: 15px;
      margin-top: 40px;
    }
    
    /* Curved & Hoverable Buttons */
    .btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      padding: 12px 24px;
      background: #003399;
      color: #fff;
      border: none;
      border-radius: 50px;
      cursor: pointer;
      transition: transform 0.3s, box-shadow 0.3s;
      font-weight: bold;
    }
    .btn:hover {
      transform: scale(1.05);
      box-shadow: 0 4px 12px rgba(0,0,0,0.3);
    }
    
    /* Fade-in Animation */
    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(20px); }
      to { opacity: 1; transform: translateY(0); }
    }
  </style>
</head>
<body>
  <!-- Header with Auth, Navigation, and Emojis -->
  <header>
    <div class="auth-buttons">
      <a href="email/login.php">🔑 Login</a>
      <a href="email/register.php">📝 Register</a>
      <a href="admin/login.php">👑 Admin</a>
    </div>
    <h1>Online Code Editor</h1>
    <nav>
      <ul>
        <li><a href="#home">🏠 Home</a></li>
        <li><a href="#about">ℹ️ About</a></li>
        <li><a href="#languages">🖥️ Languages</a></li>
        <li><a href="#developers">👨‍💻 Developers</a></li>
        <li><a href="#contact">✉️ Contact</a></li>
      </ul>
    </nav>
  </header>
  
  <!-- Main Content with Sections -->
  <main>
    <section id="home">
      <h2>Welcome</h2>
      <p>🚀 Discover the future of coding. Our platform lets you write, run, and test code in multiple languages directly from your browser. Enjoy an intuitive, dynamic experience designed for both beginners and professionals.</p>
      <button class="btn" onclick="window.location.href='editors/c_editor.php'">▶️ Try Editor</button>
    </section>
    
    <section id="about">
      <h2>About Us</h2>
      <p>We are a team of passionate developers committed to creating a seamless online coding experience. Our platform is engineered with modern technologies to deliver real-time code execution, multi-language support, and a vibrant learning environment.</p>
    </section>
    
    <section id="languages">
      <h2>Supported Languages</h2>
      <p>Choose your preferred language and start coding:</p>
      <div id="language-icons">
        <a href="editors/c_editor.php">
          <img src="assets/img/language_icons/c.png" alt="C">
          <p>C</p>
        </a>
        <a href="editors/cpp_editor.php">
          <img src="assets/img/language_icons/cpp.png" alt="C++">
          <p>C++</p>
        </a>
        <a href="editors/csharp_editor.php">
          <img src="assets/img/language_icons/csharp.png" alt="C#">
          <p>C#</p>
        </a>
        <a href="editors/java_editor.php">
          <img src="assets/img/language_icons/java.png" alt="Java">
          <p>Java</p>
        </a>
        <a href="editors/python_editor.php">
          <img src="assets/img/language_icons/python.png" alt="Python">
          <p>Python</p>
        </a>
        <a href="editors/php_editor.php">
          <img src="assets/img/language_icons/php.png" alt="PHP">
          <p>PHP</p>
        </a>
        <a href="editors/r_editor.php">
          <img src="assets/img/language_icons/r.png" alt="R">
          <p>R</p>
        </a>
        <a href="editors/html_editor.php">
          <img src="assets/img/language_icons/html.png" alt="HTML, CSS, JS">
          <p>HTML, CSS, JS</p>
        </a>
      </div>
    </section>
    
    <section id="developers">
      <h2>Developers</h2>
      <br>
      <div id="developers">
        <div class="dev-card">
          <img src="https://th.bing.com/th/id/OIP.gNI5kc8dWJPHlIpfS0FNUQHaE8?w=273&h=182&c=7&r=0&o=5&dpr=1.3&pid=1.7" alt="Developer One">
          <h3>Developer One</h3>
          <p>Front-End Specialist</p>
        </div>
        <div class="dev-card">
          <img src="https://th.bing.com/th/id/OIP.st8PlhwGeN63O3ki-5YmuAHaE7?w=273&h=182&c=7&r=0&o=5&dpr=1.3&pid=1.7" alt="Developer Two">
          <h3>Developer Two</h3>
          <p>Back-End Guru</p>
        </div>
        <div class="dev-card">
          <img src="https://th.bing.com/th/id/OIP.NupptbwifqtFD2HkMvhVtAHaE7?w=247&h=184&c=7&r=0&o=5&dpr=1.3&pid=1.7" alt="Developer Three">
          <h3>Developer Three</h3>
          <p>Full-Stack Engineer</p>
        </div>
      </div>
    </section>
    
    <section id="contact">
      <h2>Contact Us</h2>
      <p>Have questions or need support? Reach out, and we'll be happy to help! 💬</p>
      <p>Email: <a href="mailto:support@onlinecodeeditor.com">support@onlinecodeeditor.com</a></p>
      <p>Phone: (123) 456-7890</p>
      
    </section>
  </main>
  
  <!-- Footer -->
  <footer>
    <p>&copy; <?php echo date("Y"); ?> Online Code Editor. All rights reserved.</p>
  </footer>
</body>
</html>
