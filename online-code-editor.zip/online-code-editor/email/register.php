<?php
session_start();
date_default_timezone_set("Asia/Kolkata"); // Set correct timezone

// Database configuration
$servername = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "online_editor";

$conn = new mysqli($servername, $dbUsername, $dbPassword, $dbName);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$message = "";
$showOtpField = false;
$showNameField = false;

// Function to validate strong password
function isStrongPassword($password) {
    return preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/', $password);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['send_otp'])) {
        $user_email = $_POST['email'];

        // Check if email already exists
        $stmt = $conn->prepare("SELECT email FROM users WHERE email = ?");
        $stmt->bind_param("s", $user_email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $message = "<span class='error'>Email already exists. Please use a different email.</span>";
        } else {
            // Generate OTP
            $otp = rand(100000, 999999);
            $_SESSION['otp'] = $otp;
            $_SESSION['email'] = $user_email;
            $_SESSION['otp_time'] = time(); // Store OTP timestamp

            // Include PHPMailer files
            require 'PHPMailer/src/Exception.php';
            require 'PHPMailer/src/PHPMailer.php';
            require 'PHPMailer/src/SMTP.php';

            $mail = new PHPMailer\PHPMailer\PHPMailer();
            try {
                $mail->isSMTP();
                $mail->Host       = 'smtp.gmail.com';
                $mail->SMTPAuth   = true;
                $mail->Username   = 'yash455664@gmail.com';
                $mail->Password   = 'tujl gqlq luii tdvc'; // Use app password if needed
                $mail->SMTPSecure = 'tls';
                $mail->Port       = 587;

                $mail->setFrom('yash455664@gmail.com', 'Your App Name');
                $mail->addAddress($user_email);

                $mail->isHTML(true);
                $mail->Subject = 'Your OTP Verification Code';
                $mail->Body    = "Your OTP code is: <b>$otp</b>. It is valid for <b>1 minute</b>.";

                $mail->send();
                $message = "<span class='success'>OTP sent successfully to $user_email</span>";
                $showOtpField = true;
            } catch (Exception $e) {
                $message = "<span class='error'>Failed to send OTP email: " . $mail->ErrorInfo . "</span>";
            }
        }
        $stmt->close();
    }

    if (isset($_POST['verify_otp'])) {
        $entered_otp = $_POST['otp'];

        if (isset($_SESSION['otp']) && isset($_SESSION['otp_time'])) {
            $otp_time = $_SESSION['otp_time'];
            $current_time = time();

            if (($current_time - $otp_time) > 60) { // OTP expired
                $message = "<span class='error'>OTP expired! Please request a new one.</span>";
                session_unset();
                $showOtpField = false;
            } elseif ($_SESSION['otp'] == $entered_otp) {
                $_SESSION['is_verified'] = true;
                $message = "<span class='success'>OTP verification successful!</span>";
                $showNameField = true; // Show name and password fields after OTP verification
            } else {
                $message = "<span class='error'>Invalid OTP. Please try again.</span>";
                $showOtpField = true;
            }
        } else {
            $message = "<span class='error'>OTP not found. Please request again.</span>";
        }
    }

    if (isset($_POST['register'])) {
        if (!isset($_SESSION['is_verified']) || $_SESSION['is_verified'] !== true) {
            $message = "<span class='error'>Please verify your email before registering.</span>";
        } else {
            $name = $_POST['name'];
            $user_email = $_SESSION['email'];
            $password = $_POST['password'];
            $confirm_password = $_POST['confirm_password'];

            if ($password !== $confirm_password) {
                $message = "<span class='error'>Passwords do not match.</span>";
            } elseif (!isStrongPassword($password)) {
                $message = "<span class='error'>Password must be at least 8 characters long, include uppercase, lowercase, number, and special character.</span>";
            } else {
                $hashed_password = password_hash($password, PASSWORD_BCRYPT);

                $stmt = $conn->prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?)");
                $stmt->bind_param("sss", $name, $user_email, $hashed_password);

                if ($stmt->execute()) {
                    $message = "<span class='success'>Registration successful!</span>";
                    session_destroy();
                } else {
                    $message = "<span class='error'>Error: " . $stmt->error . "</span>";
                }
                $stmt->close();
            }
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Register</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: sans-serif;
            background: linear-gradient(to bottom, #2c3e50, #34495e);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        .registration-container {
            width: 90%;
            max-width: 600px;
            background-color: rgba(255, 255, 255, 0.1);
            border-radius: 10px;
            padding: 40px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }
        h2 {
            text-align: center;
            color: white;
            margin-bottom: 20px;
        }
        hr {
            border: 1px solid rgba(255, 255, 255, 0.3);
            margin-bottom: 30px;
        }
        .input-group {
            margin-bottom: 20px;
        }
        .input-group label {
            display: block;
            color: white;
            margin-bottom: 5px;
        }
        .input-group input {
            width: calc(100% - 22px);
            padding: 10px;
            border: 1px solid rgba(255, 255, 255, 0.3);
            border-radius: 5px;
            background-color: rgba(255, 255, 255, 0.2);
            color: white;
        }
        .input-group input::placeholder {
            color: rgba(255, 255, 255, 0.7);
        }
        .register-button {
            display: block;
            width: 100%;
            padding: 12px;
            background-color: rgb(11, 120, 236);
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }
        .register-button:hover {
            background-color: rgb(9, 63, 225);
        }
        .message {
            margin: 10px 0;
        }
    </style>
    <!-- Include SweetAlert2 JS -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        // OTP timer function
        function startTimer(duration) {
            let timer = duration;
            const display = document.getElementById("timer");
            const interval = setInterval(() => {
                display.textContent = `OTP expires in: ${timer}s`;
                if (--timer < 0) {
                    clearInterval(interval);
                    display.textContent = "OTP expired! Request a new one.";
                }
            }, 1000);
        }

        // If OTP field is shown, start the timer when page loads.
        <?php if ($showOtpField) { ?>
          window.onload = function () {
              startTimer(60);
          };
        <?php } ?>

        // Toggle password visibility
        function togglePasswordVisibility() {
            const passwordField = document.getElementById("password");
            const confirmPasswordField = document.getElementById("confirm_password");
            const passwordToggle = document.getElementById("password_toggle");
            const type = passwordField.type === "password" ? "text" : "password";
            passwordField.type = type;
            confirmPasswordField.type = type;
            passwordToggle.textContent = type === "password" ? "Show Password" : "Hide Password";
        }

        // Check password requirements and matching
        function validatePassword() {
            const password = document.getElementById("password").value;
            const confirmPassword = document.getElementById("confirm_password").value;
            const matchMessage = document.getElementById("password_match_message");

            if (password !== confirmPassword) {
                matchMessage.textContent = "Passwords do not match.";
                matchMessage.style.color = "rgba(74, 8, 1, 0.95)";
            } else {
                matchMessage.textContent = "Passwords match.";
                matchMessage.style.color = "rgb(9, 47, 2)";
            }

            checkPasswordRequirements(password);
        }

        function checkPasswordRequirements(password) {
            const requirements = {
                length: password.length >= 8,
                uppercase: /[A-Z]/.test(password),
                lowercase: /[a-z]/.test(password),
                number: /\d/.test(password),
                special: /[!@#$%^&*]/.test(password),
            };

            const requirementsMessage = document.getElementById("password_requirements_message");
            let html = "<ul>";
            for (const [key, value] of Object.entries(requirements)) {
                html += `<li style="color: ${value ? 'rgb(9, 47, 2)' : 'rgba(74, 8, 1, 0.95)'};">${key.charAt(0).toUpperCase() + key.slice(1)}: ${value ? '✔️' : '❌'}</li>`;
            }
            html += "</ul>";
            requirementsMessage.innerHTML = html;
        }
    </script>
</head>
<body>
    <div class="registration-container">
        <h2>Register</h2>
        <hr>
        <!-- The message div is removed in favor of SweetAlert2 popups -->
        <?php if (!empty($message)): ?>
          <script>
            document.addEventListener('DOMContentLoaded', function() {
                Swal.fire({
                    icon: <?php echo (strpos($message, 'success') !== false ? "'success'" : "'error'"); ?>,
                    title: <?php echo (strpos($message, 'success') !== false ? "'Success'" : "'Error'"); ?>,
                    html: '<?php echo addslashes($message); ?>',
                    timer: 3000,
                    showConfirmButton: false,
                    animation: true
                });
            });
          </script>
        <?php endif; ?>

        <?php if (!$showOtpField && !$showNameField): ?>
            <form method="POST" action="" onsubmit="return sendOtpAnimation();">
                <div class="input-group">
                    <label for="email">Email:</label>
                    <input type="email" name="email" required placeholder="Enter your email">
                </div>
                <button type="submit" name="send_otp" class="register-button">Send OTP</button>
            </form>
            <div style="text-align: center; margin-top: 10px;">
                <p>Already have an account? <a href="login.php" style="color: rgb(11, 120, 236);">Click here to login</a></p>
            </div>
        <?php endif; ?>

        <?php if ($showOtpField): ?>
            <div id="timer" class="timer"></div>
            <form method="POST" action="">
                <div class="input-group">
                    <label for="otp">Enter OTP:</label>
                    <input type="number" name="otp" required placeholder="Enter OTP">
                </div>
                <button type="submit" name="verify_otp" class="register-button">Verify OTP</button>
            </form>
        <?php endif; ?>

        <?php if ($showNameField): ?>
            <form method="POST" action="">
                <div class="input-group">
                    <label for="name">Name:</label>
                    <input type="text" name="name" required placeholder="Enter your name">
                </div>
                <div class="input-group">
                    <label for="password">Password:</label>
                    <input type="password" name="password" id="password" required placeholder="Enter your password" oninput="validatePassword()">
                </div>
                <div class="input-group">
                    <label for="confirm_password">Confirm Password:</label>
                    <input type="password" name="confirm_password" id="confirm_password" required placeholder="Confirm your password" oninput="validatePassword()">
                </div>
                <span id="password_match_message"></span>
                <span id="password_requirements_message"></span>
                <button type="button" id="password_toggle" onclick="togglePasswordVisibility()">Show Password</button>
                <button type="submit" name="register" class="register-button">Register</button>
            </form>
        <?php endif; ?>
    </div>
    <script>
        // Function to show OTP sending animation when the OTP form is submitted
        function sendOtpAnimation() {
            Swal.fire({
                title: 'Sending OTP...',
                html: 'Please wait while we send you the OTP.',
                didOpen: () => {
                    Swal.showLoading();
                },
                allowOutsideClick: false,
                allowEscapeKey: false,
                animation: true
            });
            return true; // Continue with form submission
        }
    </script>
</body>
</html>
