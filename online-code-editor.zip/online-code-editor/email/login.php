<?php
session_start();
date_default_timezone_set("Asia/Kolkata");

// Database configuration
$servername = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "online_editor";

$conn = new mysqli($servername, $dbUsername, $dbPassword, $dbName);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$message = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Check if email exists
    $stmt = $conn->prepare("SELECT id, password FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($id, $hashed_password);
        $stmt->fetch();

        // Verify password
        if (password_verify($password, $hashed_password)) {
            $_SESSION['user_id'] = $id;
            $_SESSION['email'] = $email;
            header("Location: ../pages/dashboard.php"); // Redirect to dashboard after successful login
            exit();
        } else {
            $message = "Invalid password. Please try again.";
        }
    } else {
        $message = "No account found with that email.";
    }
    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>User Login</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- SweetAlert2 CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
  <style>
    /* Basic Gradient Theme */
    body {
      background: linear-gradient(to right, #1E90FF, #20B2AA); /* Light blue to light sea green */
      color: #333; /* Dark gray text for contrast */
      font-family: sans-serif; /* Simple sans-serif font */
      margin: 0; /* Remove default margin */
      padding: 0; /* Remove default padding */
    }
    
    /* Heading and Link Colors */
    h1, h2, h3, h4, h5, h6 {
      color: #000; /* Black headings */
    }
    a {
      color: #007BFF; /* Link color */
      text-decoration: none; /* Remove underline */
    }
    a:hover {
      text-decoration: underline; /* Underline on hover */
    }
    
    /* Card/Container Styling */
    .login-container {
      max-width: 400px;
      margin: 50px auto;
      padding: 20px;
      background-color: #fff; /* White background for contrast */
      border-radius: 10px;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); /* Subtle box shadow */
    }
    
    .login-container h2 {
      text-align: center;
      margin-bottom: 20px;
    }
    
    .input-group {
      margin-bottom: 15px;
    }
    
    .input-group label {
      display: block;
      margin-bottom: 5px;
    }
    
    .input-group input {
      width: 100%;
      padding: 10px;
      border: 1px solid #ccc;
      border-radius: 5px;
    }
    
    .login-button {
      width: 100%;
      padding: 10px;
      border: none;
      border-radius: 5px;
      background-color: #007BFF;
      color: white;
      font-size: 16px;
      cursor: pointer;
    }
    
    .login-button:hover {
      background-color: #0056b3;
    }
    
    .links {
      text-align: center;
      margin-top: 15px;
    }
  </style>
</head>
<body>
  <div class="login-container">
    <h2>👤 User Login</h2>
    <form method="POST" action="">
      <div class="input-group">
        <label for="email">📧 Email:</label>
        <input type="email" name="email" required placeholder="Enter your email">
      </div>
      <div class="input-group">
        <label for="password">🔑 Password:</label>
        <input type="password" name="password" required placeholder="Enter your password" id="password">
      </div>
      <div class="input-group">
        <input type="checkbox" id="togglePassword">
        <label for="togglePassword">👁️ Show Password</label>
      </div>
      <button type="submit" class="login-button">🚀 Login</button>
    </form>
    <div class="links">
      <p>Don't have an account? <a href="register.php">📝 Register here</a></p>
      <p>Forgot password? <a href="forgot_password.php">🔒 Click here</a></p>
    </div>
  </div>
  
  <!-- SweetAlert2 JS -->
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <script>
    document.addEventListener("DOMContentLoaded", function() {
      <?php if (!empty($message)): ?>
        Swal.fire({
          icon: 'error',
          title: 'Login Error',
          text: '<?php echo addslashes($message); ?>',
          timer: 3000,
          showConfirmButton: false,
          animation: true
        });
      <?php endif; ?>
      
      // Toggle Password Visibility
      const togglePassword = document.getElementById('togglePassword');
      const passwordField = document.getElementById('password');
      togglePassword.addEventListener('change', function() {
          passwordField.type = this.checked ? 'text' : 'password';
      });
    });
  </script>
</body>
</html>
